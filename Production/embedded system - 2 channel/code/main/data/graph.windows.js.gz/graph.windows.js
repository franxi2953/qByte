class MainGraphWindow {
    constructor(scene, options) {
        this.scene = scene;
        this.key = options.key;
        this.title = options.title || 'Graph';
        this.series = Array.isArray(options.series) ? options.series : [];
        this.onToggle = typeof options.onToggle === 'function' ? options.onToggle : null;
        this.onClose = typeof options.onClose === 'function' ? options.onClose : null;
        this.onRequestAddTrace = typeof options.onRequestAddTrace === 'function' ? options.onRequestAddTrace : null;

        this.minimized = !!options.minimized;
        this.menuExpanded = false;
        this.menuExpandProgress = 0;
        this.menuTween = null;
        this.rangeStartPercent = 0;
        this.rangeEndPercent = 100;
        this.smoothWindow = 1;
        this.activeSlider = null;
        this.points = [];
        this.traces = [];
        this.traceNameTexts = [];
        this.traceFunctionTexts = [];
        this.traceRowHits = [];
        this.traceEditHits = [];
        this.traceDeleteHits = [];
        this.hoverNameTexts = [];
        this.hoverValueTexts = [];
        this.xTickTexts = [];
        this.yTickTexts = [];
        this.visible = true;
        this.destroyed = false;

        this.x = 0;
        this.y = 0;
        this.width = 320;
        this.height = 220;
        this.lastTitleBarDownAt = 0;

        this.titleBarHeight = 30;
        this.menuHeaderHeight = 22;
        this.container = this.scene.add.container(0, 0);
        this.graphics = this.scene.add.graphics();
        this.plotGraphics = this.scene.add.graphics();
        this.menuGraphics = this.scene.add.graphics();
        this.hoverGraphics = this.scene.add.graphics();
        this.hoverLabelGraphics = this.scene.add.graphics();
        this.windowHit = this.scene.add.zone(0, 0, this.width, this.height)
            .setOrigin(0)
            .setInteractive({ useHandCursor: true });

        this.titleText = this.scene.add.text(12, 8, this.title, {
            fontFamily: '"Montserrat Alternates"',
            fontSize: '12px',
            fontStyle: 'bold',
            color: '#e6e6e6'
        });

        this.minButton = this.scene.add.graphics();
        this.minButtonHit = this.scene.add.zone(0, 0, 18, 18)
            .setOrigin(0)
            .setInteractive({ useHandCursor: true });
        this.closeButton = this.scene.add.graphics();
        this.closeButtonHit = this.scene.add.zone(0, 0, 14, 14)
            .setOrigin(0)
            .setInteractive({ useHandCursor: true });
        this.downloadButton = this.scene.add.graphics();
        this.downloadButtonHit = this.scene.add.zone(0, 0, 16, 16)
            .setOrigin(0)
            .setInteractive({ useHandCursor: true });
        this.titleHit = this.scene.add.zone(0, 0, 120, this.titleBarHeight)
            .setOrigin(0)
            .setInteractive({ useHandCursor: true });
        this.menuHit = this.scene.add.zone(0, 0, this.width, this.menuHeaderHeight)
            .setOrigin(0)
            .setInteractive({ useHandCursor: true });
        this.addDataButton = this.scene.add.graphics();
        this.addDataHit = this.scene.add.zone(0, 0, 16, 16)
            .setOrigin(0)
            .setInteractive({ useHandCursor: true });
        this.rangeSliderHit = this.scene.add.zone(0, 0, 120, 16)
            .setOrigin(0)
            .setInteractive({ useHandCursor: true });
        this.smoothSliderHit = this.scene.add.zone(0, 0, 120, 16)
            .setOrigin(0)
            .setInteractive({ useHandCursor: true });

        this.menuTitleText = this.scene.add.text(10, 0, '', {
            fontFamily: '"Montserrat Alternates"',
            fontSize: '13px',
            fontStyle: '800',
            color: '#cad3dd'
        });

        this.menuListText = this.scene.add.text(10, 0, '', {
            fontFamily: '"Montserrat Alternates"',
            fontSize: '11px',
            fontStyle: 'bold',
            color: '#aeb7c2',
            wordWrap: { width: Math.max(120, this.width - 70) }
        });
        this.menuListText.setVisible(false);
        this.rangeLabelText = this.scene.add.text(0, 0, '', {
            fontFamily: '"Montserrat Alternates"',
            fontSize: '11px',
            fontStyle: 'bold',
            color: '#d7dfea'
        }).setVisible(false);
        this.smoothLabelText = this.scene.add.text(0, 0, '', {
            fontFamily: '"Montserrat Alternates"',
            fontSize: '11px',
            fontStyle: 'bold',
            color: '#d7dfea'
        }).setVisible(false);
        this.xAxisLabelText = this.scene.add.text(0, 0, 'Time (min)', {
            fontFamily: '"Montserrat Alternates"',
            fontSize: '10px',
            fontStyle: 'bold',
            color: '#c3ccd7'
        }).setVisible(false);

        this.hoverTooltipBg = this.scene.add.graphics();
        this.hoverTooltipText = this.scene.add.text(0, 0, '', {
            fontFamily: '"Montserrat Alternates"',
            fontSize: '10px',
            fontStyle: 'bold',
            color: '#eff4fa'
        });
        this.hoverTooltipBg.setVisible(false);
        this.hoverTooltipText.setVisible(false);

        this.chartMeta = null;
        this.hoverIndex = -1;
        this.hoverTraceIndex = -1;
        this.titleHover = false;
        this.minButtonHover = false;
        this.minButtonPressed = false;
        this.downloadButtonHover = false;
        this.downloadButtonPressed = false;
        this.closeButtonHover = false;
        this.closeButtonPressed = false;
        this.addDataHover = false;
        this.addDataPressed = false;

        this.minButtonHit.on('pointerdown', (pointer, localX, localY, event) => {
            if (event && typeof event.stopPropagation === 'function') {
                event.stopPropagation();
            }
            this.minButtonPressed = true;
            this.render();
            this.toggleMinimized();
        });
        this.minButtonHit.on('pointerup', () => {
            this.minButtonPressed = false;
            this.render();
        });
        this.minButtonHit.on('pointerover', () => {
            this.minButtonHover = true;
            this.render();
        });
        this.minButtonHit.on('pointerout', () => {
            this.minButtonHover = false;
            this.minButtonPressed = false;
            this.render();
        });

        this.closeButtonHit.on('pointerdown', (pointer, localX, localY, event) => {
            if (event && typeof event.stopPropagation === 'function') {
                event.stopPropagation();
            }
            this.closeButtonPressed = true;
            this.render();
            this.close(pointer);
        });
        this.closeButtonHit.on('pointerup', () => {
            this.closeButtonPressed = false;
            this.render();
        });
        this.closeButtonHit.on('pointerover', () => {
            this.closeButtonHover = true;
            this.render();
        });
        this.closeButtonHit.on('pointerout', () => {
            this.closeButtonHover = false;
            this.closeButtonPressed = false;
            this.render();
        });

        this.downloadButtonHit.on('pointerdown', (pointer, localX, localY, event) => {
            if (event && typeof event.stopPropagation === 'function') {
                event.stopPropagation();
            }
            this.downloadButtonPressed = true;
            this.render();
            this.downloadVisibleDataCsv();
        });
        this.downloadButtonHit.on('pointerup', () => {
            this.downloadButtonPressed = false;
            this.render();
        });
        this.downloadButtonHit.on('pointerover', () => {
            this.downloadButtonHover = true;
            this.render();
        });
        this.downloadButtonHit.on('pointerout', () => {
            this.downloadButtonHover = false;
            this.downloadButtonPressed = false;
            this.render();
        });

        this.titleHit.on('pointerdown', () => {
            this.handleTitleBarPointerDown();
        });

        this.titleHit.on('pointerover', () => {
            this.titleHover = true;
            this.render();
        });

        this.titleHit.on('pointerout', () => {
            this.titleHover = false;
            this.render();
        });

        this.menuHit.on('pointerdown', (pointer, localX, localY, event) => {
            if (event && typeof event.stopPropagation === 'function') {
                event.stopPropagation();
            }
            if (this.minimized) {
                return;
            }
            this.setMenuExpanded(!this.menuExpanded);
        });

        this.addDataHit.on('pointerdown', (pointer, localX, localY, event) => {
            if (event && typeof event.stopPropagation === 'function') {
                event.stopPropagation();
            }
            this.addDataPressed = true;
            this.render();
            if (this.minimized || this.menuExpandProgress < 0.98 || !this.onRequestAddTrace) {
                return;
            }
            this.onRequestAddTrace(this);
        });

        this.addDataHit.on('pointerup', () => {
            this.addDataPressed = false;
            this.render();
        });

        this.addDataHit.on('pointerover', () => {
            this.addDataHover = true;
            this.render();
        });

        this.addDataHit.on('pointerout', () => {
            this.addDataHover = false;
            this.addDataPressed = false;
            this.render();
        });

        const onSliderDown = (slider, localX, zone) => {
            if (slider === 'range') {
                const width = Math.max(1, Number(zone.width) || 1);
                const startX = (this.rangeStartPercent / 100) * width;
                const endX = (this.rangeEndPercent / 100) * width;
                this.activeSlider = Math.abs(localX - startX) <= Math.abs(localX - endX)
                    ? 'range-start'
                    : 'range-end';
            } else {
                this.activeSlider = slider;
            }
            this.updateSliderFromLocal(this.activeSlider, localX, zone.width);
            this.render();
        };

        this.rangeSliderHit.on('pointerdown', (pointer, localX, localY, event) => {
            if (event && typeof event.stopPropagation === 'function') event.stopPropagation();
            onSliderDown('range', localX, this.rangeSliderHit);
        });

        this.smoothSliderHit.on('pointerdown', (pointer, localX, localY, event) => {
            if (event && typeof event.stopPropagation === 'function') event.stopPropagation();
            onSliderDown('smooth', localX, this.smoothSliderHit);
        });

        this.rangeSliderHit.on('pointermove', (pointer, localX) => {
            if (!pointer.isDown) return;
            this.updateSliderFromLocal(this.activeSlider || 'range-start', localX, this.rangeSliderHit.width);
            this.render();
        });

        this.smoothSliderHit.on('pointermove', (pointer, localX) => {
            if (!pointer.isDown) return;
            this.updateSliderFromLocal('smooth', localX, this.smoothSliderHit.width);
            this.render();
        });

        this.onGlobalPointerUp = () => {
            this.activeSlider = null;
        };
        this.scene.input.on('pointerup', this.onGlobalPointerUp);

        this.windowHit.on('pointerdown', () => {
            if (this.minimized) {
                this.toggleMinimized();
            }
        });

        this.windowHit.on('pointermove', (pointer, localX, localY) => {
            this.handleChartHover(localX, localY);
        });

        this.windowHit.on('pointerout', () => {
            this.hoverIndex = -1;
            this.renderChart();
        });

        this.container.add([
            this.graphics,
            this.windowHit,
            this.plotGraphics,
            this.menuGraphics,
            this.hoverGraphics,
            this.hoverLabelGraphics,
            this.titleText,
            this.minButton,
            this.minButtonHit,
            this.closeButton,
            this.closeButtonHit,
            this.downloadButton,
            this.downloadButtonHit,
            this.titleHit,
            this.menuTitleText,
            this.menuListText,
            this.hoverTooltipBg,
            this.hoverTooltipText,
            this.rangeLabelText,
            this.smoothLabelText,
            this.xAxisLabelText,
            this.addDataButton,
            this.addDataHit,
            this.menuHit,
            this.rangeSliderHit,
            this.smoothSliderHit
        ]);

        if (Array.isArray(options.traces) && options.traces.length > 0) {
            for (let i = 0; i < options.traces.length; i++) {
                const t = options.traces[i] || {};
                this.traces.push({
                    name: t.name || `S${i + 1}`,
                    color: Number.isFinite(Number(t.color)) ? Number(t.color) : 0xffffff,
                    key: t.key || null,
                    formula: t.formula || null
                });
            }
        } else {
            const initialSeries = Array.isArray(options.series) ? options.series : [];
            for (let i = 0; i < initialSeries.length; i++) {
                const s = initialSeries[i];
                this.traces.push({
                    name: s.name || s.label || s.key || `S${i + 1}`,
                    color: s.color || 0xffffff,
                    key: s.key || null,
                    formula: null
                });
            }
        }

        this.render();
    }

    setVisible(visible) {
        this.visible = !!visible;
        this.container.setVisible(this.visible);
    }

    toggleMinimized() {
        if (this.destroyed) {
            return;
        }
        this.minimized = !this.minimized;
        this.render();
        if (this.onToggle) {
            this.onToggle(this.minimized);
        }
    }

    setFrame(x, y, width, height) {
        this.x = x;
        this.y = y;
        this.width = Math.max(this.minimized ? 120 : 220, Math.round(width));
        this.height = Math.max(this.minimized ? 120 : 160, Math.round(height));
        this.container.setPosition(this.x, this.y);
        this.render();
    }

    setData(points) {
        this.points = Array.isArray(points) ? points : [];
        this.renderChart();
    }

    addTrace(trace) {
        if (!trace || typeof trace !== 'object') {
            return;
        }
        this.traces.push(trace);
        this.render();
    }

    updateTraceAt(index, trace) {
        if (index < 0 || index >= this.traces.length || !trace || typeof trace !== 'object') {
            return;
        }
        this.traces[index] = trace;
        this.render();
    }

    setMenuExpanded(expanded) {
        const targetExpanded = !!expanded;
        this.menuExpanded = targetExpanded;
        if (this.menuTween) {
            this.menuTween.stop();
            this.menuTween = null;
        }

        this.menuTween = this.scene.tweens.add({
            targets: this,
            menuExpandProgress: targetExpanded ? 1 : 0,
            duration: 500,
            ease: 'Sine.easeInOut',
            onUpdate: () => this.render(),
            onComplete: () => {
                this.menuTween = null;
                this.render();
            }
        });
    }

    handleChartHover(localX, localY) {
        if (this.minimized || !this.chartMeta || !Array.isArray(this.chartMeta.recent) || this.chartMeta.recent.length < 2) {
            if (this.hoverIndex !== -1) {
                this.hoverIndex = -1;
                this.renderChart();
            }
            return;
        }

        const meta = this.chartMeta;
        if (localX < meta.x || localX > meta.x + meta.w || localY < meta.y || localY > meta.y + meta.h) {
            if (this.hoverIndex !== -1) {
                this.hoverIndex = -1;
                this.renderChart();
            }
            return;
        }

        let nearest = -1;
        let nearestDist = Infinity;
        for (let i = 0; i < meta.recent.length; i++) {
            const px = meta.toX(meta.recent[i].tMs);
            const d = Math.abs(px - localX);
            if (d < nearestDist) {
                nearestDist = d;
                nearest = i;
            }
        }

        if (nearest !== this.hoverIndex) {
            this.hoverIndex = nearest;
            this.renderChart();
        }
    }

    getVisibleMenuRows() {
        return Math.max(1, Math.min(6, this.traces.length));
    }

    hasWideMenuLayout() {
        return this.width >= 560;
    }

    getMenuTargetExpandedHeight() {
        const rows = this.getVisibleMenuRows();
        if (this.hasWideMenuLayout()) {
            return this.menuHeaderHeight + rows * 24 + 40;
        }
        return this.menuHeaderHeight + rows * 24 + 100;
    }

    updateSliderFromLocal(slider, localX, sliderWidth) {
        const width = Math.max(1, Number(sliderWidth) || 1);
        const p = Math.max(0, Math.min(1, localX / width));
        if (slider === 'range-start') {
            this.rangeStartPercent = Math.max(0, Math.min(99, Math.round(p * 100)));
            if (this.rangeStartPercent > this.rangeEndPercent - 1) {
                this.rangeStartPercent = this.rangeEndPercent - 1;
            }
            return;
        }
        if (slider === 'range-end') {
            this.rangeEndPercent = Math.max(1, Math.min(100, Math.round(p * 100)));
            if (this.rangeEndPercent < this.rangeStartPercent + 1) {
                this.rangeEndPercent = this.rangeStartPercent + 1;
            }
            return;
        }
        if (slider === 'smooth') {
            this.smoothWindow = Math.max(1, Math.min(20, Math.round(1 + p * 19)));
        }
    }

    getRecentByRange(points, maxPreview) {
        const n = points.length;
        if (n < 2) {
            return points.slice();
        }

        const startIdx = Math.max(0, Math.min(n - 2, Math.floor((this.rangeStartPercent / 100) * (n - 1))));
        const endIdx = Math.max(startIdx + 1, Math.min(n - 1, Math.ceil((this.rangeEndPercent / 100) * (n - 1))));
        const subset = points.slice(startIdx, endIdx + 1);
        if (subset.length <= maxPreview) {
            return subset;
        }

        const step = subset.length / maxPreview;
        const sampled = [];
        for (let i = 0; i < maxPreview; i++) {
            const idx = Math.min(subset.length - 1, Math.floor(i * step));
            sampled.push(subset[idx]);
        }
        return sampled;
    }

    buildTraceSeries(recent, traces) {
        const traceSeries = [];
        for (let s = 0; s < traces.length; s++) {
            const raw = new Array(recent.length).fill(null);
            for (let i = 0; i < recent.length; i++) {
                const v = Number(this.evaluateTraceValue(traces[s], i, recent));
                raw[i] = Number.isFinite(v) ? v : null;
            }
            traceSeries.push(this.computeSmoothedSeries(raw, this.smoothWindow));
        }
        return traceSeries;
    }

    computeSmoothedSeries(values, win) {
        const w = Math.max(1, Math.round(win));
        if (w <= 1) {
            return values.slice();
        }
        const out = new Array(values.length).fill(null);
        for (let i = 0; i < values.length; i++) {
            let sum = 0;
            let count = 0;
            const from = Math.max(0, i - w + 1);
            for (let j = from; j <= i; j++) {
                const v = values[j];
                if (!Number.isFinite(v)) continue;
                sum += v;
                count += 1;
            }
            out[i] = count > 0 ? (sum / count) : null;
        }
        return out;
    }

    getMenuHeight() {
        if (this.minimized) {
            return 0;
        }
        const expandedHeight = this.getMenuTargetExpandedHeight();
        return this.menuHeaderHeight + (expandedHeight - this.menuHeaderHeight) * this.menuExpandProgress;
    }

    render() {
        if (this.destroyed) {
            return;
        }
        this.graphics.clear();
        this.plotGraphics.clear();

        const radius = 10;
        const bodyHeight = Math.max(32, this.height - this.titleBarHeight);

        this.graphics.fillStyle(0x2e2e2e, 0.98);
        this.graphics.fillRoundedRect(0, 0, this.width, this.titleBarHeight, radius);

        this.graphics.fillStyle(this.minimized ? 0x11151b : 0x171717, 0.96);
        this.graphics.fillRoundedRect(0, this.titleBarHeight - 1, this.width, bodyHeight + 1, radius);

        this.graphics.lineStyle(1, 0xffffff, 0.14);
        this.graphics.strokeRoundedRect(0, 0, this.width, this.height, radius);

        const fullTitle = String(this.title || 'Graph');
        const shortTitle = fullTitle.length > 4 ? `${fullTitle.slice(0, 4)}...` : fullTitle;
        this.titleText.setText(this.minimized ? shortTitle : fullTitle);
        this.titleText.setPosition(12, 8);
        this.windowHit.setPosition(0, 0);
        this.windowHit.setSize(this.width, this.height);
        this.titleHit.setPosition(8, 0);
        this.titleHit.setSize(Math.max(80, this.width - 80), this.titleBarHeight);

        const showTitleTooltip = this.minimized && this.titleHover && fullTitle.length > 4;
        this.hoverTooltipBg.clear();
        if (showTitleTooltip) {
            this.hoverTooltipText.setText(fullTitle);
            const tipX = 10;
            const tipY = this.titleBarHeight + 3;
            const tipW = this.hoverTooltipText.width + 10;
            const tipH = this.hoverTooltipText.height + 6;
            this.hoverTooltipBg.fillStyle(0x0f141c, 0.95);
            this.hoverTooltipBg.fillRoundedRect(tipX, tipY, tipW, tipH, 5);
            this.hoverTooltipBg.lineStyle(1, 0xffffff, 0.2);
            this.hoverTooltipBg.strokeRoundedRect(tipX, tipY, tipW, tipH, 5);
            this.hoverTooltipText.setPosition(tipX + 5, tipY + 3);
            this.hoverTooltipBg.setVisible(true);
            this.hoverTooltipText.setVisible(true);
        } else {
            this.hoverTooltipBg.setVisible(false);
            this.hoverTooltipText.setVisible(false);
        }

        this.drawMinimizeButton();
        this.drawDownloadButton();
        this.drawCloseButton();
        this.renderChart();
        this.drawBottomMenu();
    }

    handleTitleBarPointerDown() {
        const now = Date.now();
        const elapsed = now - this.lastTitleBarDownAt;
        this.lastTitleBarDownAt = now;
        if (this.minimized) {
            return;
        }
        if (elapsed < 320) {
            this.renameTitle();
        }
    }

    renameTitle() {
        if (typeof window === 'undefined' || typeof window.prompt !== 'function') {
            return;
        }

        const next = window.prompt('Graph title', this.title);
        if (next == null) {
            return;
        }

        const normalized = String(next).trim();
        if (normalized.length === 0) {
            return;
        }

        this.title = normalized.slice(0, 48);
        this.render();
    }

    drawMinimizeButton() {
        const size = 14;
        const x = this.width - 46;
        const y = 8;

        this.minButton.clear();
        const fill = this.minButtonPressed ? 0x1f58bc : (this.minButtonHover ? 0x4a89ea : 0x2d6cdf);
        this.minButton.fillStyle(fill, 1);
        this.minButton.fillCircle(x + size / 2, y + size / 2, this.minButtonPressed ? (size / 2 - 1) : (size / 2));
        this.minButton.lineStyle(1.4, 0xffffff, 0.95);

        if (this.minimized) {
            this.minButton.lineBetween(x + 4, y + size / 2, x + size - 4, y + size / 2);
            this.minButton.lineBetween(x + size / 2, y + 4, x + size / 2, y + size - 4);
        } else {
            this.minButton.lineBetween(x + 4, y + size / 2, x + size - 4, y + size / 2);
        }

        this.minButtonHit.setPosition(x, y);
    }

    drawDownloadButton() {
        const size = 14;
        const x = this.width - 68;
        const y = 8;

        this.downloadButton.clear();
        const fill = this.downloadButtonPressed ? 0x1f7c34 : (this.downloadButtonHover ? 0x45bf62 : 0x28a745);
        this.downloadButton.fillStyle(fill, 1);
        this.downloadButton.fillCircle(x + size / 2, y + size / 2, this.downloadButtonPressed ? (size / 2 - 1) : (size / 2));
        this.downloadButton.lineStyle(1.2, 0xffffff, 0.95);
        this.downloadButton.lineBetween(x + 7, y + 4, x + 7, y + 10);
        this.downloadButton.lineBetween(x + 5, y + 8, x + 7, y + 10);
        this.downloadButton.lineBetween(x + 9, y + 8, x + 7, y + 10);
        this.downloadButton.lineBetween(x + 4, y + 11, x + 10, y + 11);
        this.downloadButtonHit.setPosition(x, y);
    }

    drawCloseButton() {
        const size = 14;
        const x = this.width - 24;
        const y = 8;

        this.closeButton.clear();
        const fill = this.closeButtonPressed ? 0xd2463f : (this.closeButtonHover ? 0xff7a74 : 0xff5f57);
        this.closeButton.fillStyle(fill, 1);
        this.closeButton.fillCircle(x + size / 2, y + size / 2, this.closeButtonPressed ? (size / 2 - 1) : (size / 2));
        this.closeButton.lineStyle(1.2, 0x2a0000, 0.75);
        this.closeButton.lineBetween(x + 4, y + 4, x + size - 4, y + size - 4);
        this.closeButton.lineBetween(x + size - 4, y + 4, x + 4, y + size - 4);
        this.closeButtonHit.setPosition(x, y);
    }

    downloadVisibleDataCsv() {
        if (typeof document === 'undefined' || typeof window === 'undefined') {
            return;
        }

        const points = this.points;
        const traces = Array.isArray(this.traces) ? this.traces : [];
        if (!Array.isArray(points) || points.length < 2 || traces.length === 0) {
            return;
        }

        const maxPreview = this.minimized ? 160 : 1200;
        const recent = this.getRecentByRange(points, maxPreview);
        if (!Array.isArray(recent) || recent.length < 2) {
            return;
        }

        const series = this.buildTraceSeries(recent, traces);
        const headers = ['t_ms', 't_s'].concat(traces.map((t) => String(t.name || 'trace')));
        const rows = [headers.join(',')];

        for (let i = 0; i < recent.length; i++) {
            const cols = [
                String(Math.round(Number(recent[i].tMs) || 0)),
                String(((Number(recent[i].tMs) || 0) / 1000).toFixed(3))
            ];
            for (let s = 0; s < traces.length; s++) {
                const v = Number(series[s][i]);
                cols.push(Number.isFinite(v) ? String(v) : '');
            }
            rows.push(cols.join(','));
        }

        const csv = `${rows.join('\n')}\n`;
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `graph-${this.title.replace(/\s+/g, '_')}-${Date.now()}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    close(pointer) {
        if (this.destroyed) {
            return;
        }

        const shiftPressed = !!(
            pointer &&
            pointer.event &&
            pointer.event.shiftKey
        );

        if (!shiftPressed && typeof window !== 'undefined' && typeof window.confirm === 'function') {
            const ok = window.confirm(`Close graph "${this.title}"?`);
            if (!ok) {
                return;
            }
        }

        this.destroyed = true;
        if (this.onClose) {
            this.onClose(this);
        }
    }

    destroy() {
        this.destroyed = true;
        if (this.titleHit) this.titleHit.destroy();
        if (this.windowHit) this.windowHit.destroy();
        if (this.menuHit) this.menuHit.destroy();
        if (this.addDataHit) this.addDataHit.destroy();
        if (this.rangeSliderHit) this.rangeSliderHit.destroy();
        if (this.smoothSliderHit) this.smoothSliderHit.destroy();
        if (this.minButtonHit) this.minButtonHit.destroy();
        if (this.closeButtonHit) this.closeButtonHit.destroy();
        if (this.downloadButtonHit) this.downloadButtonHit.destroy();
        if (this.titleText) this.titleText.destroy();
        if (this.menuTitleText) this.menuTitleText.destroy();
        if (this.menuListText) this.menuListText.destroy();
        if (this.rangeLabelText) this.rangeLabelText.destroy();
        if (this.smoothLabelText) this.smoothLabelText.destroy();
        if (this.xAxisLabelText) this.xAxisLabelText.destroy();
        if (this.hoverTooltipText) this.hoverTooltipText.destroy();
        for (let i = 0; i < this.traceNameTexts.length; i++) {
            if (this.traceNameTexts[i]) this.traceNameTexts[i].destroy();
        }
        for (let i = 0; i < this.traceFunctionTexts.length; i++) {
            if (this.traceFunctionTexts[i]) this.traceFunctionTexts[i].destroy();
        }
        for (let i = 0; i < this.traceRowHits.length; i++) {
            if (this.traceRowHits[i]) this.traceRowHits[i].destroy();
        }
        for (let i = 0; i < this.traceEditHits.length; i++) {
            if (this.traceEditHits[i]) this.traceEditHits[i].destroy();
        }
        for (let i = 0; i < this.traceDeleteHits.length; i++) {
            if (this.traceDeleteHits[i]) this.traceDeleteHits[i].destroy();
        }
        for (let i = 0; i < this.hoverValueTexts.length; i++) {
            if (this.hoverValueTexts[i]) this.hoverValueTexts[i].destroy();
        }
        for (let i = 0; i < this.hoverNameTexts.length; i++) {
            if (this.hoverNameTexts[i]) this.hoverNameTexts[i].destroy();
        }
        for (let i = 0; i < this.xTickTexts.length; i++) {
            if (this.xTickTexts[i]) this.xTickTexts[i].destroy();
        }
        for (let i = 0; i < this.yTickTexts.length; i++) {
            if (this.yTickTexts[i]) this.yTickTexts[i].destroy();
        }
        if (this.minButton) this.minButton.destroy();
        if (this.closeButton) this.closeButton.destroy();
        if (this.downloadButton) this.downloadButton.destroy();
        if (this.addDataButton) this.addDataButton.destroy();
        if (this.menuGraphics) this.menuGraphics.destroy();
        if (this.hoverTooltipBg) this.hoverTooltipBg.destroy();
        if (this.hoverLabelGraphics) this.hoverLabelGraphics.destroy();
        if (this.hoverGraphics) this.hoverGraphics.destroy();
        if (this.plotGraphics) this.plotGraphics.destroy();
        if (this.graphics) this.graphics.destroy();
        if (this.container) this.container.destroy();
        if (this.scene && this.scene.input && this.onGlobalPointerUp) {
            this.scene.input.off('pointerup', this.onGlobalPointerUp);
        }
    }

    syncHoverValueTexts(count) {
        while (this.hoverNameTexts.length < count) {
            const txt = this.scene.add.text(0, 0, '', {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '9px',
                fontStyle: 'bold',
                color: '#ffffff'
            });
            txt.setVisible(false);
            this.hoverNameTexts.push(txt);
            this.container.add(txt);
        }

        while (this.hoverValueTexts.length < count) {
            const txt = this.scene.add.text(0, 0, '', {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '9px',
                fontStyle: 'bold',
                color: '#ffffff'
            });
            txt.setVisible(false);
            this.hoverValueTexts.push(txt);
            this.container.add(txt);
        }

        for (let i = 0; i < this.hoverValueTexts.length; i++) {
            this.hoverValueTexts[i].setVisible(i < count);
        }
        for (let i = 0; i < this.hoverNameTexts.length; i++) {
            this.hoverNameTexts[i].setVisible(i < count);
        }
    }

    syncTickTexts(countX, countY) {
        while (this.xTickTexts.length < countX) {
            const txt = this.scene.add.text(0, 0, '', {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '9px',
                color: '#c3ccd7'
            });
            txt.setVisible(false);
            this.xTickTexts.push(txt);
            this.container.add(txt);
        }

        while (this.yTickTexts.length < countY) {
            const txt = this.scene.add.text(0, 0, '', {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '9px',
                color: '#c3ccd7'
            });
            txt.setVisible(false);
            this.yTickTexts.push(txt);
            this.container.add(txt);
        }

        for (let i = 0; i < this.xTickTexts.length; i++) {
            this.xTickTexts[i].setVisible(i < countX);
        }
        for (let i = 0; i < this.yTickTexts.length; i++) {
            this.yTickTexts[i].setVisible(i < countY);
        }
    }

    renderChart() {
        this.plotGraphics.clear();
        this.hoverGraphics.clear();
        this.hoverLabelGraphics.clear();
        this.hoverTooltipBg.clear();
        this.hoverTooltipBg.setVisible(false);
        this.hoverTooltipText.setVisible(false);
        this.xAxisLabelText.setVisible(false);
        this.syncHoverValueTexts(0);

        const padLeft = 12;
        const padRight = 10;
        const padTop = this.titleBarHeight + 8;
        const padBottom = this.minimized ? 10 : 44;

        const outerX = padLeft;
        const outerY = padTop;
        const outerW = Math.max(60, this.width - padLeft - padRight);
        const menuVisibleH = this.minimized
            ? 0
            : (this.menuHeaderHeight + Math.max(0, this.getMenuHeight() - this.menuHeaderHeight) * this.menuExpandProgress);
        // Reserve space for the visible data menu so axes/ticks stay above it.
        const outerH = Math.max(46, this.height - padTop - padBottom - menuVisibleH);

        const axisMarginL = this.minimized ? 6 : 34;
        const axisMarginR = this.minimized ? 6 : 8;
        const axisMarginT = this.minimized ? 6 : 10;
        const axisMarginB = this.minimized ? 6 : 24;

        const chartX = outerX + axisMarginL;
        const chartY = outerY + axisMarginT;
        const chartW = Math.max(30, outerW - axisMarginL - axisMarginR);
        const chartH = Math.max(24, outerH - axisMarginT - axisMarginB);

        this.plotGraphics.fillStyle(this.minimized ? 0x0d1117 : 0x0e1013, 1);
        this.plotGraphics.fillRect(outerX, outerY, outerW, outerH);
        this.plotGraphics.lineStyle(1, 0xffffff, 0.12);
        this.plotGraphics.strokeRect(outerX, outerY, outerW, outerH);

        const xTicks = 5;
        const yTicks = 4;
        if (!this.minimized) {
            this.plotGraphics.lineStyle(1, 0xffffff, 0.22);
            this.plotGraphics.lineBetween(chartX, chartY + chartH, chartX + chartW, chartY + chartH);
            this.plotGraphics.lineBetween(chartX, chartY, chartX, chartY + chartH);

            this.plotGraphics.lineStyle(1, 0xffffff, 0.18);
            for (let i = 0; i <= xTicks; i++) {
                const tx = chartX + (i / xTicks) * chartW;
                this.plotGraphics.lineBetween(tx, chartY + chartH, tx, chartY + chartH + 4);
            }
            for (let i = 0; i <= yTicks; i++) {
                const ty = chartY + chartH - (i / yTicks) * chartH;
                this.plotGraphics.lineBetween(chartX - 4, ty, chartX, ty);
            }
        }

        const points = this.points;
        const traces = Array.isArray(this.traces) ? this.traces : [];
        if (!Array.isArray(points) || points.length < 2 || traces.length === 0) {
            this.plotGraphics.lineStyle(1, 0x8a95a5, 0.9);
            this.plotGraphics.lineBetween(chartX + 2, chartY + chartH / 2, chartX + chartW - 2, chartY + chartH / 2);
            this.chartMeta = null;
            this.syncTickTexts(0, 0);
            return;
        }

        const maxPreview = this.minimized ? 160 : 1200;
        const recent = this.getRecentByRange(points, maxPreview);
        const tMin = recent[0].tMs;
        const tMax = recent[recent.length - 1].tMs;
        const tRange = Math.max(1, tMax - tMin);

        let yMin = Infinity;
        let yMax = -Infinity;

        const traceSeries = this.buildTraceSeries(recent, traces);

        for (let i = 0; i < recent.length; i++) {
            for (let s = 0; s < traces.length; s++) {
                const value = Number(traceSeries[s][i]);
                if (!Number.isFinite(value)) {
                    continue;
                }
                yMin = Math.min(yMin, value);
                yMax = Math.max(yMax, value);
            }
        }

        if (!Number.isFinite(yMin) || !Number.isFinite(yMax)) {
            this.plotGraphics.lineStyle(1, 0x8a95a5, 0.9);
            this.plotGraphics.lineBetween(chartX + 2, chartY + chartH / 2, chartX + chartW - 2, chartY + chartH / 2);
            this.chartMeta = null;
            this.syncTickTexts(0, 0);
            return;
        }

        const yPadding = Math.max(1, (yMax - yMin) * 0.08);
        const yLow = yMin - yPadding;
        const yHigh = yMax + yPadding;
        const yRange = Math.max(0.001, yHigh - yLow);

        const toX = (t) => chartX + 2 + ((t - tMin) / tRange) * (chartW - 4);
        const toY = (v) => chartY + chartH - 2 - ((v - yLow) / yRange) * (chartH - 4);

        if (!this.minimized) {
            this.syncTickTexts(xTicks + 1, yTicks + 1);
            for (let i = 0; i <= xTicks; i++) {
                const tx = chartX + (i / xTicks) * chartW;
                const tVal = tMin + (i / xTicks) * tRange;
                const minutes = tVal / 60000;
                const label = minutes < 10 ? `${minutes.toFixed(2)}` : `${minutes.toFixed(1)}`;
                this.xTickTexts[i].setText(label);
                this.xTickTexts[i].setPosition(tx - this.xTickTexts[i].width / 2, chartY + chartH + 6);
                this.xTickTexts[i].setVisible(true);
            }

            for (let i = 0; i <= yTicks; i++) {
                const ty = chartY + chartH - (i / yTicks) * chartH;
                const yVal = yLow + (i / yTicks) * yRange;
                const label = `${yVal.toFixed(1)}`;
                this.yTickTexts[i].setText(label);
                this.yTickTexts[i].setPosition(chartX - this.yTickTexts[i].width - 6, ty - this.yTickTexts[i].height / 2);
                this.yTickTexts[i].setVisible(true);
            }

            this.xAxisLabelText.setText('Time (min)');
            this.xAxisLabelText.setPosition(chartX + chartW / 2 - this.xAxisLabelText.width / 2, chartY + chartH + 24);
            this.xAxisLabelText.setVisible(true);
        } else {
            this.syncTickTexts(0, 0);
        }

        this.chartMeta = {
            x: chartX,
            y: chartY,
            w: chartW,
            h: chartH,
            recent,
            traces,
            toX,
            toY,
            traceSeries
        };

        const drawTrace = (s) => {
            const trace = traces[s];
            const color = trace.color || 0xffffff;
            let started = false;
            const hovered = this.hoverTraceIndex === s;
            const hasHovered = this.hoverTraceIndex >= 0;
            const lineAlpha = hasHovered ? (hovered ? 1 : 0.22) : 0.95;
            const lineWidth = this.minimized ? 1 : (hovered ? 2.2 : 1.4);
            this.plotGraphics.lineStyle(lineWidth, color, lineAlpha);
            const series = traceSeries[s];

            const pathPoints = [];
            for (let i = 0; i < recent.length; i++) {
                const value = Number(series[i]);
                if (!Number.isFinite(value)) {
                    continue;
                }
                pathPoints.push({ x: toX(recent[i].tMs), y: toY(value) });
            }

            if (pathPoints.length === 0) {
                return;
            }

            const hasCurves = typeof this.plotGraphics.quadraticCurveTo === 'function';
            this.plotGraphics.beginPath();
            this.plotGraphics.moveTo(pathPoints[0].x, pathPoints[0].y);
            if (hasCurves && pathPoints.length > 2) {
                for (let i = 1; i < pathPoints.length - 1; i++) {
                    const xc = (pathPoints[i].x + pathPoints[i + 1].x) / 2;
                    const yc = (pathPoints[i].y + pathPoints[i + 1].y) / 2;
                    this.plotGraphics.quadraticCurveTo(pathPoints[i].x, pathPoints[i].y, xc, yc);
                }
                const last = pathPoints[pathPoints.length - 1];
                const prev = pathPoints[pathPoints.length - 2];
                this.plotGraphics.quadraticCurveTo(prev.x, prev.y, last.x, last.y);
                started = true;
            } else {
                for (let i = 1; i < pathPoints.length; i++) {
                    this.plotGraphics.lineTo(pathPoints[i].x, pathPoints[i].y);
                }
                started = true;
            }

            if (started) {
                this.plotGraphics.strokePath();
            }
        };

        for (let s = 0; s < traces.length; s++) {
            if (s === this.hoverTraceIndex) continue;
            drawTrace(s);
        }
        if (this.hoverTraceIndex >= 0 && this.hoverTraceIndex < traces.length) {
            drawTrace(this.hoverTraceIndex);
        }

        if (this.minimized) {
            this.plotGraphics.fillStyle(0x000000, 0.28);
            this.plotGraphics.fillRect(chartX, chartY, chartW, 20);
            this.plotGraphics.lineStyle(1, 0xffffff, 0.08);
            this.plotGraphics.lineBetween(chartX, chartY + 20, chartX + chartW, chartY + 20);
            this.syncTickTexts(0, 0);
            return;
        }

        if (this.hoverIndex >= 0 && this.chartMeta && this.hoverIndex < recent.length) {
            const hp = recent[this.hoverIndex];
            const hx = toX(hp.tMs);
            this.hoverGraphics.lineStyle(1, 0xffffff, 0.22);
            this.hoverGraphics.lineBetween(hx, chartY, hx, chartY + chartH);

            let labelCount = 0;
            for (let i = 0; i < traces.length; i++) {
                const trace = traces[i];
                const value = Number(traceSeries[i][this.hoverIndex]);
                if (!Number.isFinite(value)) {
                    continue;
                }
                const hy = toY(value);
                this.hoverGraphics.fillStyle(trace.color || 0xffffff, 1);
                this.hoverGraphics.fillCircle(hx, hy, 3.1);
                this.hoverGraphics.lineStyle(1, 0xffffff, 0.72);
                this.hoverGraphics.strokeCircle(hx, hy, 3.1);
                this.syncHoverValueTexts(labelCount + 1);
                const nameTxt = this.hoverNameTexts[labelCount];
                const txt = this.hoverValueTexts[labelCount];
                const label = value.toFixed(3);
                const traceName = String(trace.name || `Trace ${i + 1}`);
                const traceHex = `#${(trace.color || 0xffffff).toString(16).padStart(6, '0')}`;
                nameTxt.setText(traceName);
                nameTxt.setColor(traceHex);
                txt.setText(label);
                const lw = Math.max(txt.width, nameTxt.width) + 10;
                const lh = 24;
                let lx = hx + 7;
                if (lx + lw > chartX + chartW - 2) {
                    lx = hx - lw - 7;
                }
                const ly = Math.max(chartY + 2, Math.min(chartY + chartH - lh - 2, hy - lh / 2));
                this.hoverLabelGraphics.fillStyle(0x11161d, 0.92);
                this.hoverLabelGraphics.fillRoundedRect(lx, ly, lw, lh, 4);
                this.hoverLabelGraphics.lineStyle(1, trace.color || 0xffffff, 0.9);
                this.hoverLabelGraphics.strokeRoundedRect(lx, ly, lw, lh, 4);
                nameTxt.setPosition(lx + 5, ly + 2);
                nameTxt.setVisible(true);
                txt.setPosition(lx + 5, ly + 13);
                txt.setVisible(true);
                labelCount += 1;
            }

            this.syncHoverValueTexts(labelCount);
        }
    }

    getVariableValue(point, variablePath) {
        if (!point || !variablePath) {
            return null;
        }

        if (variablePath.type === 'temperature') {
            const tempMap = {
                well1: 'temp_well1_c',
                well2: 'temp_well2_c',
                well3: 'temp_well3_c',
                lid: 'temp_lid_c'
            };
            const key = tempMap[variablePath.temperature] || 'temp_lid_c';
            const direct = Number(point[key]);
            if (Number.isFinite(direct)) {
                return direct;
            }
            if (point.vars && Number.isFinite(Number(point.vars[key]))) {
                return Number(point.vars[key]);
            }
            return null;
        }

        if (variablePath.type === 'fluorescence') {
            const sample = Number(variablePath.sample || 1);
            const light = String(variablePath.light || 'blue').toLowerCase();
            const channel = Number(variablePath.channel || 1);
            const key = `fluo_w${sample}_${light}_pd${channel}`;
            const direct = Number(point[key]);
            if (Number.isFinite(direct)) {
                return direct;
            }
            if (point.vars && Number.isFinite(Number(point.vars[key]))) {
                return Number(point.vars[key]);
            }
            return null;
        }

        return null;
    }

    evaluateOperand(expr, index, points) {
        if (!expr || !Array.isArray(points) || index < 0 || index >= points.length) {
            return null;
        }

        const mode = expr.mode || 'constant';
        if (mode === 'constant') {
            const n = Number(expr.constantValue);
            return Number.isFinite(n) ? n : null;
        }

        if (mode === 'constant-initial') {
            if (!expr.variablePath) {
                return null;
            }
            const initial = this.getVariableValue(points[0], expr.variablePath);
            return Number.isFinite(Number(initial)) ? Number(initial) : null;
        }

        if (mode !== 'variable' || !expr.variablePath) {
            return null;
        }

        const current = this.getVariableValue(points[index], expr.variablePath);
        if (!Number.isFinite(Number(current))) {
            return null;
        }

        if (expr.outputMode !== 'derivative') {
            return Number(current);
        }

        if (index === 0) {
            return null;
        }

        const prev = this.getVariableValue(points[index - 1], expr.variablePath);
        if (!Number.isFinite(Number(prev))) {
            return null;
        }

        const dtMs = Number(points[index].tMs) - Number(points[index - 1].tMs);
        if (!Number.isFinite(dtMs) || dtMs === 0) {
            return null;
        }

        return (Number(current) - Number(prev)) / (dtMs / 1000);
    }

    evaluateTraceValue(trace, index, points) {
        if (!trace) {
            return null;
        }

        if (trace.key) {
            const v = Number(points[index][trace.key]);
            return Number.isFinite(v) ? v : null;
        }

        if (!trace.formula) {
            return null;
        }

        const numerator = this.evaluateOperand(trace.formula.numerator, index, points);
        const denominator = this.evaluateOperand(trace.formula.denominator, index, points);
        if (!Number.isFinite(Number(numerator)) || !Number.isFinite(Number(denominator)) || Number(denominator) === 0) {
            return null;
        }

        return Number(numerator) / Number(denominator);
    }

    summarizeExpr(expr) {
        if (!expr) {
            return '1';
        }
        if (expr.mode === 'constant') {
            return String(expr.constantValue != null ? expr.constantValue : 1);
        }

        const vp = expr.variablePath || {};
        let varName = 'var';
        if (vp.type === 'temperature') {
            varName = `T.${vp.temperature || 'lid'}`;
        } else if (vp.type === 'fluorescence') {
            varName = `F.s${vp.sample || 1}.${vp.light || 'blue'}.c${vp.channel || 1}`;
        }

        if (expr.mode === 'constant-initial') {
            return `init(${varName})`;
        }

        if (expr.outputMode === 'derivative') {
            return `d(${varName})/dt`;
        }
        return varName;
    }

    formatTraceFunction(trace) {
        if (!trace) {
            return '1/1';
        }
        if (trace.key) {
            return trace.key;
        }
        const num = this.summarizeExpr(trace.formula && trace.formula.numerator);
        const den = this.summarizeExpr(trace.formula && trace.formula.denominator);
        return `(${num})/(${den})`;
    }

    deleteTraceAt(index, pointer) {
        if (index < 0 || index >= this.traces.length) {
            return;
        }

        const shiftPressed = !!(pointer && pointer.event && pointer.event.shiftKey);
        if (!shiftPressed && typeof window !== 'undefined' && typeof window.confirm === 'function') {
            const ok = window.confirm(`Delete trace "${this.traces[index].name}"?`);
            if (!ok) {
                return;
            }
        }

        this.traces.splice(index, 1);
        this.render();
    }

    syncTraceRowObjects(count) {
        while (this.traceNameTexts.length < count) {
            const rowHit = this.scene.add.zone(0, 0, 80, 20)
                .setOrigin(0)
                .setInteractive({ useHandCursor: true });
            const nameText = this.scene.add.text(0, 0, '', {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '12px',
                fontStyle: 'bold',
                color: '#edf2f7'
            });
            const fnText = this.scene.add.text(0, 0, '', {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '11px',
                fontStyle: 'bold',
                color: '#b7c1cd'
            });
            const delHit = this.scene.add.zone(0, 0, 14, 14)
                .setOrigin(0)
                .setInteractive({ useHandCursor: true });
            const editHit = this.scene.add.zone(0, 0, 14, 14)
                .setOrigin(0)
                .setInteractive({ useHandCursor: true });

            rowHit.on('pointerover', () => {
                const idx = Number(rowHit.getData('traceIndex'));
                if (idx >= 0 && idx !== this.hoverTraceIndex) {
                    this.hoverTraceIndex = idx;
                    this.render();
                }
            });

            rowHit.on('pointerout', () => {
                if (this.hoverTraceIndex !== -1) {
                    this.hoverTraceIndex = -1;
                    this.render();
                }
            });

            delHit.on('pointerdown', (pointer, localX, localY, event) => {
                if (event && typeof event.stopPropagation === 'function') {
                    event.stopPropagation();
                }
                const idx = Number(delHit.getData('traceIndex'));
                this.deleteTraceAt(idx, pointer);
            });

            editHit.on('pointerdown', (pointer, localX, localY, event) => {
                if (event && typeof event.stopPropagation === 'function') {
                    event.stopPropagation();
                }
                const idx = Number(editHit.getData('traceIndex'));
                if (idx >= 0 && this.onRequestAddTrace) {
                    this.onRequestAddTrace(this, idx);
                }
            });

            this.traceNameTexts.push(nameText);
            this.traceFunctionTexts.push(fnText);
            this.traceRowHits.push(rowHit);
            this.traceEditHits.push(editHit);
            this.traceDeleteHits.push(delHit);
            this.container.add([rowHit, nameText, fnText, editHit, delHit]);
        }

        for (let i = 0; i < this.traceNameTexts.length; i++) {
            const active = i < count;
            this.traceNameTexts[i].setVisible(active);
            this.traceFunctionTexts[i].setVisible(active);
            this.traceRowHits[i].setVisible(active);
            this.traceEditHits[i].setVisible(active);
            this.traceDeleteHits[i].setVisible(active);
        }
    }

    drawBottomMenu() {
        this.menuGraphics.clear();
        this.addDataButton.clear();

        if (this.minimized) {
            this.addDataHover = false;
            this.addDataPressed = false;
            this.hoverTraceIndex = -1;
            this.menuHit.setVisible(false);
            this.addDataHit.setVisible(false);
            this.rangeSliderHit.setVisible(false);
            this.smoothSliderHit.setVisible(false);
            this.rangeLabelText.setVisible(false);
            this.smoothLabelText.setVisible(false);
            this.menuTitleText.setVisible(false);
            this.menuListText.setVisible(false);
            this.syncTraceRowObjects(0);
            return;
        }

        const menuH = this.getMenuHeight();
        const menuY = this.height - menuH;
        const isExpandedEnough = this.menuExpandProgress > 0.98;

        this.menuHit.setVisible(true);
        this.menuTitleText.setVisible(true);
        this.menuListText.setVisible(false);

        this.menuGraphics.fillStyle(0x12161d, 0.9);
        this.menuGraphics.fillRoundedRect(1, menuY, this.width - 2, menuH - 1, 8);

        // Title bar style, similar to the window header.
        this.menuGraphics.fillStyle(0x2e2e2e, 0.9);
        this.menuGraphics.fillRoundedRect(1, menuY, this.width - 2, this.menuHeaderHeight, 8);
        this.menuGraphics.lineStyle(1, 0xffffff, 0.08);
        this.menuGraphics.strokeRoundedRect(1, menuY, this.width - 2, menuH - 1, 8);
        this.menuGraphics.lineBetween(1, menuY + this.menuHeaderHeight, this.width - 1, menuY + this.menuHeaderHeight);

        const arrow = this.menuExpanded ? 'v' : '^';
        this.menuTitleText.setText(`${arrow} Data`);
        this.menuTitleText.setPosition(10, menuY + 4);

        this.menuHit.setPosition(0, menuY);
        this.menuHit.setSize(this.width, this.menuHeaderHeight);

        if (!isExpandedEnough) {
            this.addDataHover = false;
            this.addDataPressed = false;
            this.hoverTraceIndex = -1;
            this.syncTraceRowObjects(0);
            this.addDataHit.setVisible(false);
            this.rangeSliderHit.setVisible(false);
            this.smoothSliderHit.setVisible(false);
            this.rangeLabelText.setVisible(false);
            this.smoothLabelText.setVisible(false);
            return;
        }

        const rowCount = this.getVisibleMenuRows();
        this.syncTraceRowObjects(rowCount);
        const wide = this.hasWideMenuLayout();
        const columnGap = wide ? 18 : 0;
        const contentTopPad = 10;
        const leftW = wide ? Math.floor(this.width * 0.55) : this.width - 16;
        const rightX = wide ? (leftW + columnGap) : 10;
        const rowY0 = menuY + this.menuHeaderHeight + contentTopPad;
        const rowH = 24;
        const nameX = 24;
        const fnX = wide ? 116 : Math.min(110, Math.floor(leftW * 0.55));
        const delX = wide ? (leftW - 10) : (this.width - 20);
        const editX = delX - 18;

        for (let i = 0; i < rowCount; i++) {
            const rowY = rowY0 + i * rowH;
            const trace = this.traces[i] || null;

            if (i === this.hoverTraceIndex) {
                this.menuGraphics.fillStyle(0x4c9fff, 0.16);
                this.menuGraphics.fillRoundedRect(4, rowY - 1, Math.max(20, leftW - 8), rowH - 2, 6);
            }

            const dotColor = trace ? (trace.color || 0xffffff) : 0x111111;
            this.menuGraphics.fillStyle(dotColor, 1);
            this.menuGraphics.fillCircle(12, rowY + 8, 5);
            this.menuGraphics.lineStyle(1, 0xffffff, 1);
            this.menuGraphics.strokeCircle(12, rowY + 8, 5);

            this.traceNameTexts[i].setText(trace ? String(trace.name || '-') : '-');
            this.traceNameTexts[i].setPosition(nameX, rowY + 2);

            this.traceFunctionTexts[i].setText(trace ? this.formatTraceFunction(trace) : '--');
            this.traceFunctionTexts[i].setPosition(fnX, rowY + 2);

            this.traceRowHits[i].setPosition(6, rowY - 1);
            this.traceRowHits[i].setSize(Math.max(20, editX - 16), rowH - 2);
            this.traceRowHits[i].setData('traceIndex', i);

            this.menuGraphics.fillStyle(0xffbd2e, 1);
            this.menuGraphics.fillCircle(editX, rowY + 8, 6);
            this.menuGraphics.lineStyle(1.1, 0x3a2b00, 0.9);
            this.menuGraphics.lineBetween(editX - 2, rowY + 10, editX + 2, rowY + 6);
            this.menuGraphics.lineBetween(editX + 2, rowY + 6, editX + 3, rowY + 7);
            this.menuGraphics.lineBetween(editX - 3, rowY + 11, editX - 1, rowY + 9);

            this.menuGraphics.fillStyle(0xff5f57, 1);
            this.menuGraphics.fillCircle(delX, rowY + 8, 6);
            this.menuGraphics.lineStyle(1.1, 0x2a0000, 0.8);
            this.menuGraphics.lineBetween(delX - 3, rowY + 5, delX + 3, rowY + 11);
            this.menuGraphics.lineBetween(delX + 3, rowY + 5, delX - 3, rowY + 11);

            this.traceEditHits[i].setPosition(editX - 7, rowY + 1);
            this.traceEditHits[i].setSize(14, 14);
            this.traceEditHits[i].setData('traceIndex', i);

            this.traceDeleteHits[i].setPosition(delX - 7, rowY + 1);
            this.traceDeleteHits[i].setSize(14, 14);
            this.traceDeleteHits[i].setData('traceIndex', i);
        }

        const slidersTop = wide ? (menuY + this.menuHeaderHeight + contentTopPad) : (rowY0 + rowCount * rowH + 8);
        const sliderW = wide ? (this.width - rightX - 14) : (this.width - 20);
        const sidePad = 12;
        const trackW = Math.max(90, sliderW - sidePad * 2);
        const labelToTrackGap = 20;
        const rowGap = 34;
        const rangeTrackX = rightX + sidePad;
        const rangeTrackY = slidersTop + labelToTrackGap;
        const smoothTrackX = rightX + sidePad;
        const smoothTrackY = slidersTop + labelToTrackGap + rowGap;

        this.rangeLabelText.setText(`Range: ${this.rangeStartPercent}% - ${this.rangeEndPercent}%`);
        this.rangeLabelText.setPosition(rightX, slidersTop);
        this.rangeLabelText.setVisible(true);
        this.smoothLabelText.setText(`Smooth: ${this.smoothWindow}`);
        this.smoothLabelText.setPosition(rightX, slidersTop + rowGap);
        this.smoothLabelText.setVisible(true);

        this.menuGraphics.fillStyle(0xffffff, 0.08);
        this.menuGraphics.fillRoundedRect(rangeTrackX, rangeTrackY - 3, trackW, 6, 3);
        this.menuGraphics.fillRoundedRect(smoothTrackX, smoothTrackY - 3, trackW, 6, 3);

        const rangeStartX = rangeTrackX + (this.rangeStartPercent / 100) * trackW;
        const rangeEndX = rangeTrackX + (this.rangeEndPercent / 100) * trackW;
        this.menuGraphics.fillStyle(0x4c9fff, 0.3);
        this.menuGraphics.fillRoundedRect(Math.min(rangeStartX, rangeEndX), rangeTrackY - 3, Math.max(2, Math.abs(rangeEndX - rangeStartX)), 6, 3);
        const smoothKnobX = smoothTrackX + ((this.smoothWindow - 1) / 19) * trackW;
        this.menuGraphics.fillStyle(0x4c9fff, 1);
        this.menuGraphics.fillCircle(rangeStartX, rangeTrackY, 5);
        this.menuGraphics.fillCircle(rangeEndX, rangeTrackY, 5);
        this.menuGraphics.fillStyle(0x65d17e, 1);
        this.menuGraphics.fillCircle(smoothKnobX, smoothTrackY, 5);

        this.rangeSliderHit.setVisible(true);
        this.rangeSliderHit.setPosition(rangeTrackX, rangeTrackY - 8);
        this.rangeSliderHit.setSize(trackW, 16);
        this.smoothSliderHit.setVisible(true);
        this.smoothSliderHit.setPosition(smoothTrackX, smoothTrackY - 8);
        this.smoothSliderHit.setSize(trackW, 16);

        const plusBaseline = wide ? (rowY0 + rowCount * rowH + 8) : (smoothTrackY + 14);
        const bx = wide ? (Math.round((leftW - 16) / 2)) : (Math.round(this.width / 2) - 8);
        const by = plusBaseline + 1;
        const plusColor = this.addDataPressed ? 0x1f65d6 : (this.addDataHover ? 0x5b9fff : 0x3a84ff);
        const plusRadius = this.addDataPressed ? 7 : 8;
        this.addDataButton.fillStyle(plusColor, 1);
        this.addDataButton.fillCircle(bx + 8, by + 8, plusRadius);
        this.addDataButton.lineStyle(1.3, 0xffffff, 0.95);
        this.addDataButton.lineBetween(bx + 4, by + 8, bx + 12, by + 8);
        this.addDataButton.lineBetween(bx + 8, by + 4, bx + 8, by + 12);

        this.addDataHit.setVisible(true);
        this.addDataHit.setPosition(bx, by);
        this.addDataHit.setSize(16, 16);
    }
}

class MainGraphsDock {
    constructor(scene, options) {
        this.scene = scene;
        this.onLayout = typeof options.onLayout === 'function' ? options.onLayout : null;
        this.windows = [];
        this.visible = true;
        this.seedCounter = 0;
        this.area = {
            x: options.x || 0,
            y: options.y || 0,
            width: options.width || 480,
            height: options.height || 320
        };

        this.dockButtonState = {
            add: { hover: false, pressed: false },
            save: { hover: false, pressed: false },
            load: { hover: false, pressed: false }
        };

        this.addButtonG = this.scene.add.graphics();
        this.addButtonHit = this.scene.add.zone(0, 0, 24, 24)
            .setOrigin(0)
            .setInteractive({ useHandCursor: true });
        this.saveButtonG = this.scene.add.graphics();
        this.saveButtonHit = this.scene.add.zone(0, 0, 24, 24)
            .setOrigin(0)
            .setInteractive({ useHandCursor: true });
        this.loadButtonG = this.scene.add.graphics();
        this.loadButtonHit = this.scene.add.zone(0, 0, 24, 24)
            .setOrigin(0)
            .setInteractive({ useHandCursor: true });
        this.bindDockButtonState(this.addButtonHit, 'add', () => this.createNewWindow());
        this.bindDockButtonState(this.saveButtonHit, 'save', () => this.saveGraphLayout());
        this.bindDockButtonState(this.loadButtonHit, 'load', () => this.loadGraphLayout());
        this.traceModalEl = null;
    }

    bindDockButtonState(hit, key, onClick) {
        hit.on('pointerdown', () => {
            this.dockButtonState[key].pressed = true;
            this.drawAddButton(true);
        });
        hit.on('pointerup', () => {
            this.dockButtonState[key].pressed = false;
            this.drawAddButton(true);
            onClick();
        });
        hit.on('pointerover', () => {
            this.dockButtonState[key].hover = true;
            this.drawAddButton(true);
        });
        hit.on('pointerout', () => {
            this.dockButtonState[key].hover = false;
            this.dockButtonState[key].pressed = false;
            this.drawAddButton(true);
        });
    }

    addWindow(options) {
        const win = new MainGraphWindow(this.scene, {
            ...options,
            onToggle: () => {
                this.layout();
                if (this.onLayout) {
                    this.onLayout();
                }
            },
            onClose: (closingWindow) => {
                this.removeWindow(closingWindow);
            },
            onRequestAddTrace: (targetWindow, editIndex) => {
                this.openTraceBuilder(targetWindow, editIndex);
            }
        });
        this.windows.push(win);
        this.layout();
        return win;
    }

    removeWindow(target) {
        const idx = this.windows.indexOf(target);
        if (idx >= 0) {
            const removed = this.windows.splice(idx, 1)[0];
            if (removed) {
                removed.destroy();
            }
        }
        this.layout();
        if (this.onLayout) {
            this.onLayout();
        }
    }

    createNewWindow() {
        this.seedCounter += 1;
        const idx = this.seedCounter;

        this.addWindow({
            key: `custom-${Date.now()}-${idx}`,
            title: `Graph ${this.windows.length + 1}`,
            minimized: true,
            series: []
        });
    }

    setData(points) {
        for (let i = 0; i < this.windows.length; i++) {
            this.windows[i].setData(points);
        }
    }

    setVisible(visible) {
        this.visible = !!visible;
        this.windows.forEach((win) => win.setVisible(this.visible));
        this.addButtonG.setVisible(this.visible);
        this.addButtonHit.setVisible(this.visible);
        this.saveButtonG.setVisible(this.visible);
        this.saveButtonHit.setVisible(this.visible);
        this.loadButtonG.setVisible(this.visible);
        this.loadButtonHit.setVisible(this.visible);
    }

    serializeLayout() {
        return {
            version: 1,
            savedAt: Date.now(),
            windows: this.windows
                .filter((w) => !w.destroyed)
                .map((w) => ({
                    title: w.title,
                    minimized: !!w.minimized,
                    traces: (w.traces || []).map((t) => ({
                        name: t.name,
                        color: t.color,
                        key: t.key || null,
                        formula: t.formula || null
                    }))
                }))
        };
    }

    applyLayout(layout) {
        if (!layout || !Array.isArray(layout.windows)) {
            return false;
        }

        const current = this.windows.slice();
        for (let i = 0; i < current.length; i++) {
            this.removeWindow(current[i]);
        }

        for (let i = 0; i < layout.windows.length; i++) {
            const w = layout.windows[i] || {};
            this.addWindow({
                key: `loaded-${Date.now()}-${i}`,
                title: String(w.title || `Graph ${i + 1}`).slice(0, 48),
                minimized: !!w.minimized,
                traces: Array.isArray(w.traces) ? w.traces : [],
                series: []
            });
        }

        this.layout();
        if (this.onLayout) {
            this.onLayout();
        }
        return true;
    }

    async fetchGraphLibrary() {
        const response = await fetch('/graphs', { cache: 'no-store' });
        const raw = await response.text();
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        const parsed = JSON.parse(raw || '{}');
        if (!parsed || typeof parsed !== 'object') {
            return {};
        }
        return parsed;
    }

    async saveGraphLayout() {
        try {
            const lib = await this.fetchGraphLibrary();
            const nameRaw = window.prompt('Save graph setup as', 'default');
            if (nameRaw == null) {
                return;
            }
            const name = String(nameRaw).trim();
            if (!name) {
                return;
            }

            if (lib[name]) {
                const overwrite = window.confirm(`A graph setup named "${name}" exists. Overwrite?`);
                if (!overwrite) {
                    return;
                }
            }

            const payload = this.serializeLayout();
            const url = `/graphs?save_new=1&name=${encodeURIComponent(name)}&graph_data=${encodeURIComponent(JSON.stringify(payload))}`;
            const response = await fetch(url, { cache: 'no-store' });
            const text = await response.text();
            if (!response.ok || text.indexOf('[ERROR]') >= 0) {
                throw new Error(text || `HTTP ${response.status}`);
            }
        } catch (err) {
            window.alert(`Failed to save graphs: ${String(err)}`);
        }
    }

    async loadGraphLayout() {
        try {
            const lib = await this.fetchGraphLibrary();
            const names = Object.keys(lib || {});
            if (names.length === 0) {
                window.alert('No saved graph setups yet.');
                return;
            }

            const chosen = window.prompt(`Load graph setup:\n${names.join('\n')}`, names[0]);
            if (chosen == null) {
                return;
            }
            const key = String(chosen).trim();
            if (!key || !lib[key]) {
                window.alert('Graph setup not found.');
                return;
            }

            const ok = this.applyLayout(lib[key]);
            if (!ok) {
                window.alert('Saved graph setup is invalid.');
            }
        } catch (err) {
            window.alert(`Failed to load graphs: ${String(err)}`);
        }
    }

    setArea(x, y, width, height) {
        this.area = {
            x: x,
            y: y,
            width: Math.max(220, width),
            height: Math.max(140, height)
        };
        this.layout();
    }

    layout() {
        if (!this.visible) {
            this.drawAddButton(false);
            return;
        }

        if (this.windows.length === 0) {
            this.drawAddButton(true);
            return;
        }

        const activeWindows = this.windows.filter((win) => !win.destroyed);
        const expanded = activeWindows.filter((win) => !win.minimized);
        const minimized = activeWindows.filter((win) => win.minimized);

        const gap = 10;
        const square = this.area.width >= 780 ? 138 : 122;
        const cols = Math.max(1, Math.floor((this.area.width + gap) / (square + gap)));
        const miniRows = minimized.length > 0 ? Math.ceil(minimized.length / cols) : 0;
        const miniZoneHeight = miniRows > 0 ? (miniRows * square) + ((miniRows - 1) * gap) + 16 : 0;
        this.drawAddButton(minimized.length > 0);

        const expandedAreaHeight = Math.max(120, this.area.height - (miniZoneHeight > 0 ? miniZoneHeight + gap : 0));

        if (expanded.length > 0) {
            const perHeight = Math.max(160, Math.floor((expandedAreaHeight - (expanded.length - 1) * gap) / expanded.length));
            let y = this.area.y;
            expanded.forEach((win) => {
                win.setVisible(true);
                win.setFrame(this.area.x, y, this.area.width, perHeight);
                y += perHeight + gap;
            });
        }

        if (minimized.length > 0) {
            const baseY = this.area.y + this.area.height - miniZoneHeight;

            minimized.forEach((win, index) => {
                win.setVisible(true);
                const row = Math.floor(index / cols);
                const col = index % cols;
                const x = this.area.x + col * (square + gap);
                const y = baseY + row * (square + gap);
                win.setFrame(x, y, square, square);
            });
        }

        for (let i = 0; i < expanded.length; i++) {
            expanded[i].setVisible(true);
        }
    }

    drawAddButton(show) {
        const size = 24;
        const x = this.area.x + this.area.width - size;
        const y = this.area.y + this.area.height - size;
        const saveX = x - 30;
        const loadX = x - 60;

        this.addButtonG.clear();
        this.saveButtonG.clear();
        this.loadButtonG.clear();
        if (!show) {
            this.dockButtonState.add.hover = false;
            this.dockButtonState.add.pressed = false;
            this.dockButtonState.save.hover = false;
            this.dockButtonState.save.pressed = false;
            this.dockButtonState.load.hover = false;
            this.dockButtonState.load.pressed = false;
            this.addButtonG.setVisible(false);
            this.addButtonHit.setVisible(false);
            this.saveButtonG.setVisible(false);
            this.saveButtonHit.setVisible(false);
            this.loadButtonG.setVisible(false);
            this.loadButtonHit.setVisible(false);
            return;
        }

        const addFill = this.dockButtonState.add.pressed ? 0x1f65d6 : (this.dockButtonState.add.hover ? 0x5b9fff : 0x3a84ff);
        this.addButtonG.fillStyle(addFill, 1);
        this.addButtonG.fillCircle(x + size / 2, y + size / 2, this.dockButtonState.add.pressed ? (size / 2 - 1) : (size / 2));
        this.addButtonG.lineStyle(1.8, 0xffffff, 0.95);
        this.addButtonG.lineBetween(x + 7, y + size / 2, x + size - 7, y + size / 2);
        this.addButtonG.lineBetween(x + size / 2, y + 7, x + size / 2, y + size - 7);

        this.addButtonHit.setPosition(x, y);
        this.addButtonHit.setSize(size, size);
        this.addButtonG.setVisible(this.visible);
        this.addButtonHit.setVisible(this.visible);

        const saveFill = this.dockButtonState.save.pressed ? 0x1f7c34 : (this.dockButtonState.save.hover ? 0x45bf62 : 0x28a745);
        this.saveButtonG.fillStyle(saveFill, 1);
        this.saveButtonG.fillCircle(saveX + size / 2, y + size / 2, this.dockButtonState.save.pressed ? (size / 2 - 1) : (size / 2));
        this.saveButtonG.lineStyle(1.4, 0xffffff, 0.95);
        this.saveButtonG.lineBetween(saveX + 7, y + 9, saveX + 17, y + 9);
        this.saveButtonG.lineBetween(saveX + 7, y + 9, saveX + 7, y + 15);
        this.saveButtonG.lineBetween(saveX + 17, y + 9, saveX + 17, y + 15);
        this.saveButtonG.lineBetween(saveX + 7, y + 15, saveX + 17, y + 15);
        this.saveButtonHit.setPosition(saveX, y);
        this.saveButtonHit.setSize(size, size);
        this.saveButtonG.setVisible(this.visible);
        this.saveButtonHit.setVisible(this.visible);

        const loadFill = this.dockButtonState.load.pressed ? 0xd88412 : (this.dockButtonState.load.hover ? 0xffb347 : 0xff9f1a);
        this.loadButtonG.fillStyle(loadFill, 1);
        this.loadButtonG.fillCircle(loadX + size / 2, y + size / 2, this.dockButtonState.load.pressed ? (size / 2 - 1) : (size / 2));
        this.loadButtonG.lineStyle(1.4, 0xffffff, 0.95);
        this.loadButtonG.lineBetween(loadX + 12, y + 7, loadX + 12, y + 15);
        this.loadButtonG.lineBetween(loadX + 9, y + 12, loadX + 12, y + 15);
        this.loadButtonG.lineBetween(loadX + 15, y + 12, loadX + 12, y + 15);
        this.loadButtonHit.setPosition(loadX, y);
        this.loadButtonHit.setSize(size, size);
        this.loadButtonG.setVisible(this.visible);
        this.loadButtonHit.setVisible(this.visible);
    }

    getPalettes() {
        return [
            {
                key: 'mac',
                label: 'macOS',
                colors: ['#28c840', '#ffbd2e', '#ff5f57', '#4c9fff', '#9b7dff', '#00d4ff']
            },
            {
                key: 'viridis',
                label: 'Viridis',
                colors: ['#440154', '#414487', '#2a788e', '#22a884', '#7ad151', '#fde725']
            },
            {
                key: 'magma',
                label: 'Magma',
                colors: ['#000004', '#3b0f70', '#8c2981', '#de4968', '#fe9f6d', '#fcfdbf']
            },
            {
                key: 'tableau',
                label: 'Tableau 10',
                colors: ['#4e79a7', '#f28e2b', '#e15759', '#76b7b2', '#59a14f', '#edc948', '#b07aa1', '#ff9da7', '#9c755f', '#bab0ab']
            },
            {
                key: 'set2',
                label: 'Set2',
                colors: ['#66c2a5', '#fc8d62', '#8da0cb', '#e78ac3', '#a6d854', '#ffd92f', '#e5c494', '#b3b3b3']
            },
            {
                key: 'okabeito',
                label: 'Okabe-Ito',
                colors: ['#0072B2', '#E69F00', '#009E73', '#D55E00', '#56B4E9', '#CC79A7', '#F0E442', '#000000']
            }
        ];
    }

    openTraceBuilder(targetWindow, editIndex = -1) {
        if (!targetWindow || typeof document === 'undefined') {
            return;
        }

        const isEditing = Number.isInteger(editIndex) && editIndex >= 0 && editIndex < targetWindow.traces.length;
        const existingTrace = isEditing ? targetWindow.traces[editIndex] : null;

        if (this.traceModalEl && this.traceModalEl.parentNode) {
            this.traceModalEl.parentNode.removeChild(this.traceModalEl);
            this.traceModalEl = null;
        }

        const palettes = this.getPalettes();
        let activePalette = palettes[0];
        let activeColor = activePalette.colors[0];
        let selectedSide = 'numerator';

        const defaultExpr = () => ({
            mode: 'constant',
            constantValue: 1,
            outputMode: 'absolute',
            variablePath: {
                type: 'temperature',
                temperature: 'well1',
                sample: 1,
                light: 'red',
                channel: 1
            }
        });

        const exprState = {
            numerator: defaultExpr(),
            denominator: defaultExpr()
        };

        const cloneExpr = (expr) => {
            if (!expr || typeof expr !== 'object') {
                return defaultExpr();
            }
            const vp = expr.variablePath || {};
            return {
                mode: expr.mode || 'constant',
                constantValue: Number.isFinite(Number(expr.constantValue)) ? Number(expr.constantValue) : 1,
                outputMode: expr.outputMode || 'absolute',
                variablePath: {
                    type: vp.type || 'temperature',
                    temperature: vp.temperature || 'well1',
                    sample: Number.isFinite(Number(vp.sample)) ? Number(vp.sample) : 1,
                    light: vp.light || 'red',
                    channel: Number.isFinite(Number(vp.channel)) ? Number(vp.channel) : 1
                }
            };
        };

        if (existingTrace && existingTrace.formula) {
            exprState.numerator = cloneExpr(existingTrace.formula.numerator);
            exprState.denominator = cloneExpr(existingTrace.formula.denominator);
        }

        const traceColorHex = existingTrace && Number.isFinite(Number(existingTrace.color))
            ? `#${Number(existingTrace.color).toString(16).padStart(6, '0')}`
            : null;
        if (traceColorHex) {
            activeColor = traceColorHex;
            const foundPalette = palettes.find((p) => p.colors.some((c) => String(c).toLowerCase() === traceColorHex.toLowerCase()));
            if (foundPalette) {
                activePalette = foundPalette;
            }
        }
        const overlay = document.createElement('div');
        overlay.style.position = 'fixed';
        overlay.style.inset = '0';
        overlay.style.background = 'rgba(0,0,0,0.55)';
        overlay.style.display = 'flex';
        overlay.style.alignItems = 'center';
        overlay.style.justifyContent = 'center';
        overlay.style.zIndex = '15000';

        const panel = document.createElement('div');
        panel.style.width = '760px';
        panel.style.maxWidth = '92vw';
        panel.style.maxHeight = '90vh';
        panel.style.overflow = 'auto';
        panel.style.background = '#101319';
        panel.style.border = '1px solid rgba(255,255,255,0.16)';
        panel.style.borderRadius = '12px';
        panel.style.padding = '14px';
        panel.style.boxSizing = 'border-box';
        panel.style.color = '#e6edf5';
        panel.style.fontFamily = '"Montserrat Alternates", sans-serif';

        const title = document.createElement('div');
        title.textContent = isEditing ? 'Edit Data Trace' : 'Add Data Trace';
        title.style.fontWeight = '700';
        title.style.marginBottom = '10px';
        panel.appendChild(title);

        const makeLabel = (text) => {
            const l = document.createElement('div');
            l.textContent = text;
            l.style.fontSize = '12px';
            l.style.fontWeight = '700';
            l.style.marginTop = '8px';
            l.style.marginBottom = '4px';
            l.style.color = '#c7d0db';
            return l;
        };

        const nameInput = document.createElement('input');
        nameInput.type = 'text';
        nameInput.value = existingTrace && existingTrace.name
            ? String(existingTrace.name)
            : `Trace ${targetWindow.traces.length + 1}`;
        nameInput.style.width = '100%';
        nameInput.style.height = '34px';
        nameInput.style.background = '#0a0f15';
        nameInput.style.color = '#e6edf5';
        nameInput.style.border = '1px solid rgba(255,255,255,0.18)';
        nameInput.style.borderRadius = '8px';
        nameInput.style.padding = '0 10px';
        nameInput.style.boxSizing = 'border-box';
        nameInput.style.fontFamily = '"Montserrat Alternates", sans-serif';
        nameInput.style.fontSize = '13px';
        nameInput.style.fontWeight = '700';

        const paletteTabs = document.createElement('div');
        paletteTabs.style.display = 'flex';
        paletteTabs.style.flexWrap = 'wrap';
        paletteTabs.style.gap = '6px';

        const colorSwatches = document.createElement('div');
        colorSwatches.style.display = 'flex';
        colorSwatches.style.flexWrap = 'wrap';
        colorSwatches.style.gap = '8px';
        colorSwatches.style.marginTop = '6px';

        const formulaAndOptions = document.createElement('div');
        formulaAndOptions.style.display = 'grid';
        formulaAndOptions.style.gridTemplateColumns = '1fr 1fr';
        formulaAndOptions.style.gap = '12px';
        formulaAndOptions.style.marginTop = '12px';

        const formulaPane = document.createElement('div');
        formulaPane.style.border = '1px solid rgba(255,255,255,0.12)';
        formulaPane.style.borderRadius = '10px';
        formulaPane.style.background = '#0d1117';
        formulaPane.style.padding = '10px';

        const formulaTitle = document.createElement('div');
        formulaTitle.textContent = 'Expression';
        formulaTitle.style.fontSize = '12px';
        formulaTitle.style.fontWeight = '700';
        formulaTitle.style.marginBottom = '8px';
        formulaPane.appendChild(formulaTitle);

        const fractionWrap = document.createElement('div');
        fractionWrap.style.display = 'flex';
        fractionWrap.style.flexDirection = 'column';
        fractionWrap.style.alignItems = 'stretch';
        fractionWrap.style.gap = '6px';

        const numeratorBox = document.createElement('div');
        const denominatorBox = document.createElement('div');
        [numeratorBox, denominatorBox].forEach((box) => {
            box.style.minHeight = '44px';
            box.style.display = 'flex';
            box.style.alignItems = 'center';
            box.style.justifyContent = 'center';
            box.style.padding = '4px 8px';
            box.style.borderRadius = '8px';
            box.style.border = '1px solid rgba(255,255,255,0.16)';
            box.style.cursor = 'pointer';
            box.style.userSelect = 'none';
            box.style.transition = 'all 0.15s ease';
            box.style.textAlign = 'center';
            box.style.fontSize = '12px';
            box.style.fontWeight = '700';
        });

        const divisionLine = document.createElement('div');
        divisionLine.style.height = '2px';
        divisionLine.style.borderRadius = '2px';
        divisionLine.style.background = 'rgba(255,255,255,0.7)';
        divisionLine.style.margin = '0 8px';

        fractionWrap.appendChild(numeratorBox);
        fractionWrap.appendChild(divisionLine);
        fractionWrap.appendChild(denominatorBox);
        formulaPane.appendChild(fractionWrap);

        const optionsPane = document.createElement('div');
        optionsPane.style.border = '1px solid rgba(255,255,255,0.12)';
        optionsPane.style.borderRadius = '10px';
        optionsPane.style.background = '#0d1117';
        optionsPane.style.padding = '10px';

        const optionsTitle = document.createElement('div');
        optionsTitle.textContent = 'Builder';
        optionsTitle.style.fontSize = '12px';
        optionsTitle.style.fontWeight = '700';
        optionsTitle.style.marginBottom = '8px';
        optionsPane.appendChild(optionsTitle);

        const optionsContent = document.createElement('div');
        optionsPane.appendChild(optionsContent);

        const toExprLabel = (expr) => {
            if (!expr) return '1';
            if (expr.mode === 'constant') return String(expr.constantValue != null ? expr.constantValue : 1);
            const vp = expr.variablePath || {};
            const varName = vp.type === 'temperature'
                ? `T.${vp.temperature || 'well1'}`
                : `F.s${vp.sample || 1}.${vp.light || 'red'}.c${vp.channel || 1}`;
            if (expr.mode === 'constant-initial') return `init(${varName})`;
            return expr.outputMode === 'derivative' ? `d(${varName})/dt` : varName;
        };

        const styleSelectable = (el, selected) => {
            el.style.background = selected ? 'rgba(76,159,255,0.22)' : 'rgba(255,255,255,0.03)';
            el.style.border = selected ? '1px solid rgba(76,159,255,0.85)' : '1px solid rgba(255,255,255,0.16)';
            el.style.color = selected ? '#eaf3ff' : '#d6deea';
        };

        const makeChoiceButton = (text, selected, onClick) => {
            const b = document.createElement('button');
            b.type = 'button';
            b.textContent = text;
            b.style.padding = '7px 10px';
            b.style.borderRadius = '8px';
            b.style.fontFamily = '"Montserrat Alternates", sans-serif';
            b.style.fontSize = '11px';
            b.style.fontWeight = '700';
            b.style.cursor = 'pointer';
            b.style.transition = 'all 0.12s ease';
            styleSelectable(b, selected);
            b.onmouseenter = () => {
                if (!selected) b.style.background = 'rgba(255,255,255,0.08)';
            };
            b.onmouseleave = () => {
                styleSelectable(b, selected);
            };
            b.onclick = onClick;
            return b;
        };

        const groupTitle = (text) => {
            const t = document.createElement('div');
            t.textContent = text;
            t.style.fontFamily = '"Montserrat Alternates", sans-serif';
            t.style.fontWeight = '700';
            t.style.fontSize = '12px';
            t.style.marginTop = '8px';
            t.style.marginBottom = '6px';
            t.style.color = '#dbe3ee';
            return t;
        };

        const addChoiceRow = (parent, label, values, currentValue, onPick) => {
            parent.appendChild(groupTitle(label));
            const row = document.createElement('div');
            row.style.display = 'flex';
            row.style.flexWrap = 'wrap';
            row.style.gap = '6px';
            values.forEach((v) => {
                const text = String(v.label != null ? v.label : v.value);
                const val = v.value != null ? v.value : v;
                const selected = String(val) === String(currentValue);
                row.appendChild(makeChoiceButton(text, selected, () => {
                    onPick(val);
                    renderFormulaUI();
                    renderOptionsUI();
                }));
            });
            parent.appendChild(row);
        };

        const renderPaletteUI = () => {
            paletteTabs.innerHTML = '';
            colorSwatches.innerHTML = '';

            palettes.forEach((p) => {
                const selected = p.key === activePalette.key;
                const tab = makeChoiceButton(p.label, selected, () => {
                    activePalette = p;
                    activeColor = p.colors[0];
                    renderPaletteUI();
                });
                tab.style.padding = '6px 10px';
                paletteTabs.appendChild(tab);
            });

            activePalette.colors.forEach((hex) => {
                const sw = document.createElement('button');
                sw.type = 'button';
                sw.style.width = '22px';
                sw.style.height = '22px';
                sw.style.borderRadius = '999px';
                sw.style.background = hex;
                sw.style.cursor = 'pointer';
                sw.style.border = hex === activeColor ? '2px solid #ffffff' : '1px solid rgba(255,255,255,0.28)';
                sw.onclick = () => {
                    activeColor = hex;
                    renderPaletteUI();
                };
                colorSwatches.appendChild(sw);
            });

            const hasActiveInPalette = activePalette.colors.some((c) => String(c).toLowerCase() === String(activeColor).toLowerCase());
            if (!hasActiveInPalette) {
                const sw = document.createElement('button');
                sw.type = 'button';
                sw.style.width = '22px';
                sw.style.height = '22px';
                sw.style.borderRadius = '999px';
                sw.style.background = activeColor;
                sw.style.cursor = 'pointer';
                sw.style.border = '2px solid #ffffff';
                sw.onclick = () => {
                    renderPaletteUI();
                };
                colorSwatches.appendChild(sw);
            }
        };

        const renderFormulaUI = () => {
            numeratorBox.textContent = toExprLabel(exprState.numerator);
            denominatorBox.textContent = toExprLabel(exprState.denominator);
            styleSelectable(numeratorBox, selectedSide === 'numerator');
            styleSelectable(denominatorBox, selectedSide === 'denominator');
        };

        numeratorBox.onclick = () => {
            selectedSide = 'numerator';
            renderFormulaUI();
            renderOptionsUI();
        };
        denominatorBox.onclick = () => {
            selectedSide = 'denominator';
            renderFormulaUI();
            renderOptionsUI();
        };

        const renderOptionsUI = () => {
            optionsContent.innerHTML = '';
            const expr = exprState[selectedSide];

            addChoiceRow(optionsContent, `${selectedSide} type`, [
                { value: 'constant', label: 'constant' },
                { value: 'constant-initial', label: 'constant initial' },
                { value: 'variable', label: 'variable' }
            ], expr.mode, (v) => {
                expr.mode = v;
            });

            if (expr.mode === 'constant') {
                optionsContent.appendChild(groupTitle('constant value'));
                const inp = document.createElement('input');
                inp.type = 'number';
                inp.step = 'any';
                inp.value = String(expr.constantValue != null ? expr.constantValue : 1);
                inp.style.width = '170px';
                inp.style.maxWidth = '100%';
                inp.style.height = '32px';
                inp.style.borderRadius = '8px';
                inp.style.border = '1px solid rgba(255,255,255,0.18)';
                inp.style.background = '#0a0f15';
                inp.style.color = '#e6edf5';
                inp.style.padding = '0 8px';
                inp.oninput = () => {
                    const n = Number(inp.value);
                    expr.constantValue = Number.isFinite(n) ? n : 1;
                    renderFormulaUI();
                };
                optionsContent.appendChild(inp);
                return;
            }

            addChoiceRow(optionsContent, 'variable family', [
                { value: 'temperature', label: 'temperature' },
                { value: 'fluorescence', label: 'fluorescence' }
            ], expr.variablePath.type, (v) => {
                expr.variablePath.type = v;
            });

            if (expr.variablePath.type === 'temperature') {
                addChoiceRow(optionsContent, 'temperature', [
                    { value: 'well1', label: 'well1' },
                    { value: 'well2', label: 'well2' },
                    { value: 'well3', label: 'well3' },
                    { value: 'lid', label: 'lid' }
                ], expr.variablePath.temperature, (v) => {
                    expr.variablePath.temperature = v;
                });
            } else {
                addChoiceRow(optionsContent, 'sample', Array.from({ length: 8 }).map((_, i) => ({ value: i + 1, label: `sample ${i + 1}` })), expr.variablePath.sample, (v) => {
                    expr.variablePath.sample = Number(v);
                });
                addChoiceRow(optionsContent, 'light', [
                    { value: 'red', label: 'red' },
                    { value: 'green', label: 'green' },
                    { value: 'blue', label: 'blue' }
                ], expr.variablePath.light, (v) => {
                    expr.variablePath.light = v;
                });
                addChoiceRow(optionsContent, 'channel', [
                    { value: 1, label: 'ch 1' },
                    { value: 2, label: 'ch 2' }
                ], expr.variablePath.channel, (v) => {
                    expr.variablePath.channel = Number(v);
                });
            }

            if (expr.mode === 'variable') {
                addChoiceRow(optionsContent, 'output', [
                    { value: 'absolute', label: 'absolute' },
                    { value: 'derivative', label: 'derivative d/dt' }
                ], expr.outputMode, (v) => {
                    expr.outputMode = v;
                });
            }
        };

        panel.appendChild(makeLabel('Trace name'));
        panel.appendChild(nameInput);
        panel.appendChild(makeLabel('Palette'));
        panel.appendChild(paletteTabs);
        panel.appendChild(colorSwatches);
        formulaAndOptions.appendChild(formulaPane);
        formulaAndOptions.appendChild(optionsPane);
        panel.appendChild(formulaAndOptions);

        renderPaletteUI();
        renderFormulaUI();
        renderOptionsUI();

        const actions = document.createElement('div');
        actions.style.display = 'flex';
        actions.style.justifyContent = 'flex-end';
        actions.style.gap = '8px';
        actions.style.marginTop = '12px';

        const cancelBtn = document.createElement('button');
        cancelBtn.type = 'button';
        cancelBtn.textContent = 'Cancel';
        const addBtn = document.createElement('button');
        addBtn.type = 'button';
        addBtn.textContent = isEditing ? 'Save' : 'Add';

        [cancelBtn, addBtn].forEach((btn) => {
            btn.style.height = '28px';
            btn.style.padding = '0 12px';
            btn.style.borderRadius = '7px';
            btn.style.border = '1px solid rgba(255,255,255,0.2)';
            btn.style.background = '#2a303a';
            btn.style.color = '#e6edf5';
            btn.style.cursor = 'pointer';
        });
        addBtn.style.background = '#2f6df0';

        const closeModal = () => {
            if (overlay.parentNode) {
                overlay.parentNode.removeChild(overlay);
            }
            this.traceModalEl = null;
        };

        cancelBtn.addEventListener('click', closeModal);
        overlay.addEventListener('click', (event) => {
            if (event.target === overlay) {
                closeModal();
            }
        });

        addBtn.addEventListener('click', () => {
            const name = String(nameInput.value || '').trim() || `Trace ${targetWindow.traces.length + 1}`;
            const colorHex = activeColor || '#ffffff';
            const color = Number.parseInt(colorHex.replace('#', ''), 16);

            const nextTrace = {
                name: name,
                color: Number.isFinite(color) ? color : 0xffffff,
                key: existingTrace && existingTrace.key ? existingTrace.key : null,
                formula: {
                    numerator: cloneExpr(exprState.numerator),
                    denominator: cloneExpr(exprState.denominator)
                }
            };

            if (isEditing) {
                targetWindow.updateTraceAt(editIndex, nextTrace);
            } else {
                targetWindow.addTrace(nextTrace);
            }

            closeModal();
        });

        actions.appendChild(cancelBtn);
        actions.appendChild(addBtn);
        panel.appendChild(actions);
        overlay.appendChild(panel);
        document.body.appendChild(overlay);
        this.traceModalEl = overlay;
    }

    destroy() {
        this.windows.forEach((win) => win.destroy());
        this.windows = [];
        if (this.addButtonHit) this.addButtonHit.destroy();
        if (this.addButtonG) this.addButtonG.destroy();
        if (this.saveButtonHit) this.saveButtonHit.destroy();
        if (this.saveButtonG) this.saveButtonG.destroy();
        if (this.loadButtonHit) this.loadButtonHit.destroy();
        if (this.loadButtonG) this.loadButtonG.destroy();
        if (this.traceModalEl && this.traceModalEl.parentNode) {
            this.traceModalEl.parentNode.removeChild(this.traceModalEl);
            this.traceModalEl = null;
        }
    }
}
