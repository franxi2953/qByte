let taskQueue = [];
let activeTask = null;
let processing = false;
let sequence = 0;
let completedCount = 0;
const recurringTasks = new Map();

const PRIORITY = {
    high: 0,
    normal: 1,
    low: 2
};

function asPriority(value) {
    if (typeof value === 'number' && Number.isFinite(value)) {
        return Math.max(0, Math.floor(value));
    }
    if (typeof value === 'string' && PRIORITY[value] != null) {
        return PRIORITY[value];
    }
    return PRIORITY.normal;
}

function queueSnapshot() {
    postMessage({
        type: 'queue',
        active: activeTask ? {
            id: activeTask.id,
            kind: activeTask.kind,
            endpoint: activeTask.endpoint,
            priority: activeTask.priority
        } : null,
        pending: taskQueue.map((task) => ({
            id: task.id,
            kind: task.kind,
            endpoint: task.endpoint,
            priority: task.priority
        })),
        recurring: Array.from(recurringTasks.values()).map((entry) => ({
            name: entry.name,
            kind: entry.template.kind,
            endpoint: entry.template.endpoint,
            priority: entry.template.priority,
            intervalMs: entry.intervalMs
        })),
        completedCount: completedCount
    });
}

function enqueue(task) {
    const normalized = {
        id: ++sequence,
        kind: task.kind || 'fetch',
        endpoint: task.endpoint || '/OnGoing',
        priority: asPriority(task.priority),
        parser: task.parser || 'text'
    };

    taskQueue.push(normalized);
    taskQueue.sort((a, b) => {
        if (a.priority !== b.priority) {
            return a.priority - b.priority;
        }
        return a.id - b.id;
    });

    queueSnapshot();
    processQueue();
}

function parseResponse(raw, parser) {
    if (parser === 'json') {
        return JSON.parse(raw);
    }
    if (parser === 'number') {
        return Number(String(raw).trim());
    }
    return raw;
}

async function runTask(task) {
    const started = Date.now();
    try {
        const response = await fetch(task.endpoint, { cache: 'no-store' });
        const elapsed = Date.now() - started;
        const raw = await response.text();

        if (task.kind === 'ping') {
            postMessage({
                type: 'ping',
                connected: response.ok,
                pingMs: elapsed,
                endpoint: task.endpoint
            });
            return;
        }

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        postMessage({
            type: 'data',
            endpoint: task.endpoint,
            parser: task.parser,
            value: parseResponse(raw, task.parser),
            elapsedMs: elapsed
        });
    } catch (err) {
        if (task.kind === 'ping') {
            postMessage({
                type: 'ping',
                connected: false,
                pingMs: null,
                endpoint: task.endpoint,
                error: String(err)
            });
            return;
        }

        postMessage({
            type: 'data-error',
            endpoint: task.endpoint,
            error: String(err)
        });
    }
}

async function processQueue() {
    if (processing) {
        return;
    }

    processing = true;
    while (taskQueue.length > 0) {
        activeTask = taskQueue.shift();
        queueSnapshot();
        await runTask(activeTask);
        completedCount += 1;
        activeTask = null;
        queueSnapshot();
    }
    processing = false;
}

function startIntervalEnqueue(template, intervalMs) {
    const fallbackName = `${template.kind || 'task'}:${template.endpoint || '/unknown'}`;
    const name = template.name || fallbackName;

    removeRecurringTask(name);

    const interval = Math.max(250, Number(intervalMs) || 1000);
    const timer = setInterval(() => enqueue(template), interval);

    recurringTasks.set(name, {
        name: name,
        intervalMs: interval,
        timer: timer,
        template: {
            name: name,
            kind: template.kind || 'fetch',
            endpoint: template.endpoint || '/OnGoing',
            parser: template.parser || 'text',
            priority: asPriority(template.priority)
        }
    });

    enqueue(template);
    queueSnapshot();
}

function removeRecurringTask(name) {
    const entry = recurringTasks.get(name);
    if (!entry) {
        return;
    }
    clearInterval(entry.timer);
    recurringTasks.delete(name);
    queueSnapshot();
}

function stopAll() {
    const names = Array.from(recurringTasks.keys());
    names.forEach((name) => removeRecurringTask(name));
    taskQueue = [];
    activeTask = null;
    processing = false;
    queueSnapshot();
}

onmessage = (event) => {
    const data = event.data || {};

    if (data.type === 'start') {
        startIntervalEnqueue({
            name: data.name || 'ping',
            kind: 'ping',
            endpoint: data.endpoint || '/ping',
            priority: data.priority || 'high'
        }, data.intervalMs || 1000);
    }

    if (data.type === 'startDataPoll') {
        startIntervalEnqueue({
            name: data.name || 'data-poll',
            kind: 'fetch',
            endpoint: data.endpoint || '/device-info',
            parser: data.parser || 'json',
            priority: data.priority || 'low'
        }, data.intervalMs || 3000);
    }

    if (data.type === 'addRecurring') {
        startIntervalEnqueue({
            name: data.name,
            kind: data.kind,
            endpoint: data.endpoint,
            parser: data.parser,
            priority: data.priority
        }, data.intervalMs || 1000);
    }

    if (data.type === 'removeRecurring') {
        removeRecurringTask(data.name);
    }

    if (data.type === 'enqueue') {
        enqueue({
            kind: data.kind,
            endpoint: data.endpoint,
            parser: data.parser,
            priority: data.priority
        });
    }

    if (data.type === 'stop') {
        stopAll();
    }
};
