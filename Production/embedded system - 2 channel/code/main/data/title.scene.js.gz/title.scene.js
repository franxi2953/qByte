class TitleScene extends Phaser.Scene {
    constructor() {
        super({ key: 'TitleScene' });
        this.barWidth = 320;
        this.barHeight = 8;
        this.barRadius = 4;
        this.completedCount = 0;
        this.totalCount = 0;
        this.displayedBarWidth = 0;
        this.cacheName = 'qbyte-assets-v401';
        this.statusText = null;
        this.requiredFiles = [
            '/index.html',
            '/montserrat.css',
            '/phaser.min.js',
            '/title.scene.js',
            '/ui.scene.js',
            '/graph.windows.js',
            '/worker.js',
            '/ma-r.woff2',
            '/ma-b.woff2',
            '/ma-xb.woff2'
        ];
        this.startupTasks = [
            { key: 'deviceInfo', path: '/device-info', parser: 'json' },
            { key: 'deviceConfig', path: '/device-config', parser: 'json' },
            { key: 'credentialsFile', path: '/credentials.txt', parser: 'text' },
            { key: 'configFile', path: '/config.txt', parser: 'json' },
            { key: 'onGoing', path: '/OnGoing', parser: 'text' },
            { key: 'cycleTime', path: '/cycle_time', parser: 'text' },
            { key: 'weights', path: '/weights', parser: 'csv' },
            { key: 'lidTemp', path: '/lid_temp', parser: 'number' },
            { key: 'lidDiff', path: '/lid_diff', parser: 'number' },
            { key: 'meltingStep', path: '/melting_step', parser: 'number' },
            { key: 'meltingTime', path: '/melting_time', parser: 'number' },
            { key: 'meltingRange', path: '/melting_range', parser: 'csv' },
            { key: 'freeMemory', path: '/free_memory', parser: 'text' }
        ];
    }

    preload() {}

    create() {
        this.waitForFonts().then(() => {
            this.buildTitleScreen();
            this.startLoadingPipeline();
        });
    }

    async waitForFonts() {
        if (!document.fonts || !document.fonts.load) {
            return;
        }

        await Promise.all([
            document.fonts.load('400 12px "Montserrat Alternates"'),
            document.fonts.load('700 12px "Montserrat Alternates"'),
            document.fonts.load('800 48px "Montserrat Alternates"')
        ]);
    }

    buildTitleScreen() {
        const centerX = this.cameras.main.width / 2;
        const centerY = this.cameras.main.height / 2;

        // Add "qByte" text
        this.loadingText = this.add.text(centerX, centerY - 56, 'qByte', {
            fontFamily: '"Montserrat Alternates"',
            fontStyle: 'bold',
            fontSize: '48px',
            color: '#fff',
            align: 'center'
        }).setOrigin(0.5);

        // Loading bar background
        this.barX = centerX - this.barWidth / 2;
        this.barY = centerY + 10;

        this.statusText = this.add.text(centerX, this.barY - 18, 'Preparing assets...', {
            fontFamily: '"Montserrat Alternates"',
            fontSize: '11px',
            color: '#bbbbbb',
            align: 'center'
        }).setOrigin(0.5, 0.5);

        this.barBg = this.add.graphics();
        this.barBg.fillStyle(0x222222, 0.8);
        this.barBg.fillRoundedRect(this.barX, this.barY, this.barWidth, this.barHeight, this.barRadius);

        this.barFill = this.add.graphics();
        this.drawBar(0);

        this.totalCount = this.requiredFiles.length + this.startupTasks.length;

        const footerY = this.barY + this.barHeight + 14;
        this.add.text(this.barX, footerY, 'v4.0.1 (LumiLAMP)', {
            fontFamily: '"Montserrat Alternates"',
            fontStyle: 'bold',
            fontSize: '10px',
            color: '#ffffff'
        }).setOrigin(0, 0);

        this.add.text(this.barX + this.barWidth, footerY, 'Fran Quero GPL-3.0', {
            fontFamily: '"Montserrat Alternates"',
            fontStyle: 'bold',
            fontSize: '10px',
            color: '#ffffff'
        }).setOrigin(1, 0);
    }

    update() {}

    drawBar(width) {
        this.barFill.clear();
        this.barFill.fillStyle(0xffffff, 1);
        if (width > 0) {
            this.barFill.fillRoundedRect(this.barX, this.barY, width, this.barHeight, this.barRadius);
        }
    }

    setStatus(message) {
        if (this.statusText) {
            this.statusText.setText(message);
        }
    }

    advanceBar() {
        const targetWidth = (this.completedCount / this.totalCount) * this.barWidth;
        this.tweens.addCounter({
            from: this.displayedBarWidth,
            to: targetWidth,
            duration: 220,
            onUpdate: (tween) => {
                this.displayedBarWidth = tween.getValue();
                this.drawBar(this.displayedBarWidth);
            }
        });
    }

    parsePayload(raw, parserType) {
        if (parserType === 'json') {
            return JSON.parse(raw);
        }
        if (parserType === 'number') {
            return Number(String(raw).trim());
        }
        if (parserType === 'csv') {
            return String(raw)
                .split(',')
                .map((item) => item.trim())
                .filter((item) => item.length > 0);
        }
        return raw;
    }

    async loadStaticAssets() {
        if (!window.__qbyteAssetCache) {
            window.__qbyteAssetCache = {};
        }

        let cache = null;
        if (window.caches && window.caches.open) {
            cache = await window.caches.open(this.cacheName);
        }

        for (let i = 0; i < this.requiredFiles.length; i++) {
            const file = this.requiredFiles[i];
            this.setStatus(`Loading ${file}...`);

            try {
                let response = null;
                let source = 'network';

                if (cache) {
                    const cached = await cache.match(file);
                    if (cached) {
                        response = cached.clone();
                        source = 'cache';
                    }
                }

                if (!response) {
                    response = await fetch(file, { cache: 'no-cache' });
                    if (!response.ok) {
                        throw new Error(`HTTP ${response.status}`);
                    }
                    if (cache) {
                        await cache.put(file, response.clone());
                    }
                }

                window.__qbyteAssetCache[file] = {
                    ready: true,
                    source: source,
                    cachedAt: Date.now()
                };

                this.completedCount += 1;
                this.setStatus(`Loaded ${file} (${source})`);
                this.advanceBar();
            } catch (err) {
                window.__qbyteAssetCache[file] = {
                    ready: false,
                    error: String(err)
                };
                this.setStatus(`Error loading ${file}`);
            }

            await new Promise((resolve) => setTimeout(resolve, 120));
        }
    }

    async loadStartupTasks() {
        if (!window.__qbyteStartup) {
            window.__qbyteStartup = {
                values: {},
                order: [],
                errors: {}
            };
        }

        for (let i = 0; i < this.startupTasks.length; i++) {
            const task = this.startupTasks[i];
            this.setStatus(`Startup ${task.path}...`);

            try {
                const response = await fetch(task.path, { cache: 'no-cache' });
                const raw = await response.text();

                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}`);
                }

                const parsed = this.parsePayload(raw, task.parser);
                window.__qbyteStartup.values[task.key] = parsed;
                window.__qbyteStartup.order.push(task.key);

                this.completedCount += 1;
                this.advanceBar();
                this.setStatus(`Startup ready: ${task.key}`);
            } catch (err) {
                window.__qbyteStartup.errors[task.key] = String(err);
                this.setStatus(`Startup error: ${task.key}`);
            }

            await new Promise((resolve) => setTimeout(resolve, 90));
        }
    }

    async startLoadingPipeline() {
        await this.loadStaticAssets();
        await this.loadStartupTasks();

        if (this.completedCount === this.totalCount) {
            this.setStatus('All startup data ready');
        } else {
            this.setStatus('Startup finished with warnings');
        }

        this.time.delayedCall(1000, () => {
            this.scene.start('UIScene');
        });
    }
}
