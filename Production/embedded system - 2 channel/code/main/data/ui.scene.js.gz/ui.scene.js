    class MacWindow {
        constructor(scene, options) {
            this.scene = scene;
            this.x = options.x;
            this.y = options.y;
            this.width = options.width || 360;
            this.expandedHeight = options.height || 180;
            this.title = options.title || 'Window';
            this.onToggle = typeof options.onToggle === 'function' ? options.onToggle : null;

            this.titleBarHeight = 30;
            this.padding = 12;
            this.collapsed = !!options.collapsed;
            this.expandProgress = this.collapsed ? 0 : 1;
            this.toggleTween = null;

            this.container = this.scene.add.container(this.x, this.y);
            this.graphics = this.scene.add.graphics();
            this.container.add(this.graphics);

            this.titleText = this.scene.add.text(12, 8, this.title, {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '12px',
                fontStyle: 'bold',
                color: '#e6e6e6'
            });

            this.collapseIcon = this.scene.add.graphics();

            this.content = this.scene.add.container(0, this.titleBarHeight);

            this.headerHitArea = this.scene.add.zone(this.width / 2, this.titleBarHeight / 2, this.width, this.titleBarHeight)
                .setOrigin(0.5)
                .setInteractive({ useHandCursor: true });

            this.headerHitArea.on('pointerdown', () => {
                this.toggle();
            });

            this.container.add([
                this.titleText,
                this.collapseIcon,
                this.content,
                this.headerHitArea
            ]);

            this.render();
        }

        getHeight() {
            const bodyHeight = Math.max(0, this.expandedHeight - this.titleBarHeight);
            return this.titleBarHeight + bodyHeight * this.expandProgress;
        }

        addContent(gameObject, x = 0, y = 0) {
            gameObject.setPosition(this.padding + x, this.padding + y);
            this.content.add(gameObject);
            return gameObject;
        }

        setPosition(x, y) {
            this.x = x;
            this.y = y;
            this.container.setPosition(x, y);
        }

        toggle() {
            this.collapsed = !this.collapsed;

            if (this.toggleTween) {
                this.toggleTween.stop();
                this.toggleTween = null;
            }

            const target = this.collapsed ? 0 : 1;
            this.toggleTween = this.scene.tweens.add({
                targets: this,
                expandProgress: target,
                duration: 500,
                ease: 'Sine.easeInOut',
                onUpdate: () => {
                    this.render();
                    if (this.onToggle) {
                        this.onToggle(this.collapsed);
                    }
                },
                onComplete: () => {
                    this.render();
                    if (this.onToggle) {
                        this.onToggle(this.collapsed);
                    }
                }
            });
        }

        render() {
            const radius = 10;
            const bodyHeight = Math.max(0, this.expandedHeight - this.titleBarHeight);
            const renderedBodyHeight = bodyHeight * this.expandProgress;

            this.graphics.clear();

            this.graphics.fillStyle(0x2e2e2e, 0.98);
            this.graphics.fillRoundedRect(0, 0, this.width, this.titleBarHeight, radius);

            this.graphics.fillStyle(0x171717, 0.96);
            if (renderedBodyHeight > 0.2) {
                this.graphics.fillRoundedRect(0, this.titleBarHeight - 1, this.width, renderedBodyHeight + 1, radius);
            }

            this.graphics.lineStyle(1, 0xffffff, 0.12);
            this.graphics.strokeRoundedRect(0, 0, this.width, this.getHeight(), radius);

            this.content.setVisible(this.expandProgress > 0.02);
            this.content.setAlpha(this.expandProgress);
            this.drawCollapseIcon();
        }

        drawCollapseIcon() {
            const cx = this.width - 18;
            const cy = this.titleBarHeight / 2;
            const s = 5;

            this.collapseIcon.clear();
            this.collapseIcon.fillStyle(0xd0d0d0, 1);

            if (this.collapsed) {
                // Right-pointing filled triangle
                this.collapseIcon.fillTriangle(
                    cx - s / 2, cy - s,
                    cx - s / 2, cy + s,
                    cx + s, cy
                );
            } else {
                // Down-pointing filled triangle
                this.collapseIcon.fillTriangle(
                    cx - s, cy - s / 2,
                    cx + s, cy - s / 2,
                    cx, cy + s
                );
            }
        }
    }

    class UIScene extends Phaser.Scene {
        constructor() {
            super({ key: 'UIScene' });
            this.pingWorker = null;
            this.connectionDot = null;
            this.ipText = null;
            this.pingText = null;
            this.ssidText = null;
            this.mdnsText = null;
            this.memoryLabelText = null;
            this.pingGraph = null;
            this.memoryBar = null;
            this.pingHistory = new Array(10).fill(null);
            this.freeMemoryPercent = null;
            this.deviceInfoTimer = null;
            this.identity = { ip: 'N/A', ssid: 'N/A', mdns: 'qbyte.local' };
            this.windows = [];
            this.queueWindowText = null;
            this.queueItemsText = null;
            this.queueRecurringText = null;
            this.queueLeftTableText = null;
            this.queueRightTableText = null;
            this.queueLeftCells = [];
            this.queueRightCells = [];
            this.protocolRunning = false;
            this.protocolConfig = {
                cycleTimeSec: 60,
                lidTemp: 95,
                lidDiff: 5,
                meltingStep: 1,
                meltingTimeSec: 10,
                rangeStart: 30,
                rangeEnd: 60,
                runTempC: 50,
                isMelting: false
            };
            this.protocolValueTexts = {};
            this.protocolActionContainer = null;
            this.protocolFields = {};
            this.rangeSlider = null;
            this.activeProtocolField = null;
            this.meltingOptionsContainer = null;
            this.fieldCaretTween = null;
            this.meltingVisibilityObjects = [];
            this.meltingCollapseTween = null;
            this.protocolActionExpandedY = 0;
            this.protocolActionCollapsedY = 0;
            this.protocolWindow = null;
            this.protocolWindowExpandedHeight = 358;
            this.protocolWindowCollapsedHeight = 232;
            this.protocolWindowHeightTween = null;
            this.helpTooltip = null;
            this.helpTooltipBg = null;
            this.helpTooltipText = null;
            this.summaryWindow = null;
            this.summaryInfoText = null;
            this.summaryLegendText = null;
            this.summaryChart = null;
            this.summaryRawPayload = '';
            this.rawDataOverlayEl = null;
            this.rawDataTitleEl = null;
            this.rawDataTableWrapEl = null;
            this.rawDataTableEl = null;
            this.rawDataCloseEl = null;
            this.rawDataDownloadEl = null;
            this.summaryState = {
                count: 0,
                spanMs: 0,
                startMs: null,
                endMs: null,
                lastMemoryPct: null,
                points: [],
                source: 'none'
            };
            this.graphDock = null;
            this.mainGraphWindows = {};
        }

        getIdentityFromStartup(startupValues) {
            let ip = 'N/A';
            let ssid = 'N/A';
            let mdns = 'qbyte.local';

            const host = window.location.hostname || '';
            const ipv4Pattern = /^(25[0-5]|2[0-4]\d|1?\d?\d)(\.(25[0-5]|2[0-4]\d|1?\d?\d)){3}$/;

            const deviceConfig = startupValues.deviceConfig;
            if (deviceConfig && typeof deviceConfig === 'object') {
                if (deviceConfig.ip) ip = deviceConfig.ip;
                if (deviceConfig.ssid) ssid = deviceConfig.ssid;
            }

            const deviceInfo = startupValues.deviceInfo;
            if (deviceInfo && typeof deviceInfo === 'object') {
                if (deviceInfo.ip) ip = String(deviceInfo.ip);
                if (deviceInfo.ssid) ssid = String(deviceInfo.ssid);
                if (deviceInfo.mdns) {
                    mdns = String(deviceInfo.mdns);
                }
            }

            if (ip === 'N/A' && ipv4Pattern.test(host)) {
                ip = host;
            }

            const credentialsRaw = startupValues.credentialsFile;
            if (ssid === 'N/A' && typeof credentialsRaw === 'string' && credentialsRaw.length > 0) {
                const first = credentialsRaw.split(',')[0];
                if (first && first.trim().length > 0) {
                    ssid = first.trim();
                }
            }

            return { ip, ssid, mdns };
        }

        create() {
            const width = this.cameras.main.width;
            const startup = (window.__qbyteStartup && window.__qbyteStartup.values) || {};
            const identity = this.getIdentityFromStartup(startup);
            this.identity = identity;
            this.initializeProtocolConfig(startup);
            this.freeMemoryPercent = this.parseMemoryPercent(startup.freeMemory);

            this.add.rectangle(0, 0, width, 44, 0x000000, 1).setOrigin(0, 0);

            this.connectionDot = this.add.circle(22, 22, 5, 0xff5f57).setOrigin(0.5);
            this.connectionDot.setStrokeStyle(1, 0xffffff, 1);

            const textStyle = {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '12px',
                color: '#ffffff'
            };

            this.ipText = this.add.text(42, 12, `IP: ${this.identity.ip}`, textStyle).setOrigin(0, 0).setPadding(0, 2, 0, 2);
            this.pingText = this.add.text(42, 12, 'PING: -- ms', textStyle).setOrigin(0, 0).setPadding(0, 2, 0, 2);
            this.ssidText = this.add.text(42, 12, `SSID: ${this.identity.ssid}`, textStyle).setOrigin(0, 0).setPadding(0, 2, 0, 2);
            this.mdnsText = this.add.text(42, 12, `mDNS: ${this.identity.mdns}`, textStyle).setOrigin(0, 0).setPadding(0, 2, 0, 2);
            this.memoryLabelText = this.add.text(42, 12, 'memory', {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '11px',
                color: '#cfd4d8'
            }).setOrigin(0, 0).setPadding(0, 2, 0, 2);

            this.pingGraph = this.add.graphics();
            this.memoryBar = this.add.graphics();
            this.initHelpTooltip();
            this.layoutTopBar();

            this.createMainWindows();
            this.initRawDataOverlay();

            this.scale.on('resize', () => {
                this.layoutWindows();
                this.layoutRawDataOverlay();
            });

            this.setupProtocolFieldKeyboard();

            this.setupPingWorker();
            this.startDeviceInfoRefresh();
        }

        initHelpTooltip() {
            this.helpTooltipBg = this.add.graphics();
            this.helpTooltipText = this.add.text(0, 0, '', {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '10px',
                color: '#eef2f7',
                wordWrap: { width: 220 }
            }).setOrigin(0, 0);
            this.helpTooltip = this.add.container(0, 0, [this.helpTooltipBg, this.helpTooltipText]);
            this.helpTooltip.setDepth(9999);
            this.helpTooltip.setVisible(false);
        }

        setupProtocolFieldKeyboard() {
            if (!this.input || !this.input.keyboard) {
                return;
            }

            this.input.keyboard.on('keydown', (event) => {
                if (!this.activeProtocolField) {
                    return;
                }

                const field = this.protocolFields[this.activeProtocolField];
                if (!field || !field.textObj) {
                    return;
                }

                let text = field.textObj.text || '';
                if (event.key === 'Backspace') {
                    field.textObj.setText(text.slice(0, -1));
                    this.updateFieldCaretPosition(field);
                    return;
                }
                if (event.key === 'Enter') {
                    if (typeof field.apply === 'function') {
                        field.apply();
                    }
                    this.setActiveProtocolField(null);
                    return;
                }
                if (event.key === 'Escape' || event.key === 'Tab') {
                    this.setActiveProtocolField(null);
                    return;
                }

                if (event.key.length === 1 && /[0-9.]/.test(event.key)) {
                    if (!field.allowDecimal && event.key === '.') {
                        return;
                    }
                    if (event.key === '.' && text.includes('.')) {
                        return;
                    }
                    if (text.length < 10) {
                        field.textObj.setText(text + event.key);
                        this.updateFieldCaretPosition(field);
                    }
                }
            });
        }

        initializeProtocolConfig(startup) {
            const cycleRaw = Number(startup.cycleTime);
            const lidTempRaw = Number(startup.lidTemp);
            const lidDiffRaw = Number(startup.lidDiff);
            const stepRaw = Number(startup.meltingStep);
            const stepTimeRaw = Number(startup.meltingTime);
            const rangeRaw = Array.isArray(startup.meltingRange) ? startup.meltingRange : [];

            if (Number.isFinite(cycleRaw) && cycleRaw > 0) {
                this.protocolConfig.cycleTimeSec = Math.max(1, Math.round(cycleRaw / 1000));
            }
            if (Number.isFinite(lidTempRaw)) {
                this.protocolConfig.lidTemp = Math.round(lidTempRaw);
            }
            if (Number.isFinite(lidDiffRaw)) {
                this.protocolConfig.lidDiff = Math.round(lidDiffRaw);
            }
            if (Number.isFinite(stepRaw)) {
                this.protocolConfig.meltingStep = stepRaw;
            }
            if (Number.isFinite(stepTimeRaw) && stepTimeRaw > 0) {
                this.protocolConfig.meltingTimeSec = Math.max(1, Math.round(stepTimeRaw / 1000));
            }
            if (rangeRaw.length >= 2) {
                const left = Number(rangeRaw[0]);
                const right = Number(rangeRaw[1]);
                if (Number.isFinite(left)) this.protocolConfig.rangeStart = left;
                if (Number.isFinite(right)) this.protocolConfig.rangeEnd = right;
            }

            const ongoingRaw = String(startup.onGoing || '').trim();
            this.protocolRunning = ongoingRaw === '1';
        }

        createMainWindows() {
            const usableWidth = Math.min(420, this.cameras.main.width - 24);

            const overviewWindow = new MacWindow(this, {
                x: 12,
                y: 56,
                width: usableWidth,
                height: 240,
                title: 'Worker Queue',
                onToggle: () => this.layoutWindows()
            });

            const style = {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '12px',
                color: '#f5f5f5'
            };

            this.queueWindowText = overviewWindow.addContent(this.add.text(0, 0, 'Active: idle\nPending: 0\nCompleted: 0', style), 0, 0);
            this.buildQueueTables(overviewWindow);

            const controlsWindow = new MacWindow(this, {
                x: 12,
                y: 238,
                width: usableWidth,
                height: 358,
                title: 'Protocol Run',
                onToggle: () => this.layoutWindows()
            });
            this.protocolWindow = controlsWindow;

            this.buildProtocolConfigWindow(controlsWindow);

            const summaryWindow = new MacWindow(this, {
                x: 12,
                y: 608,
                width: usableWidth,
                height: 304,
                title: 'Data Summary',
                onToggle: () => this.layoutWindows()
            });
            this.summaryWindow = summaryWindow;
            this.buildDataSummaryWindow(summaryWindow);

            this.windows = [overviewWindow, controlsWindow, summaryWindow];
            this.initMainGraphWindows();
            this.layoutWindows();
        }

        initMainGraphWindows() {
            if (typeof MainGraphsDock !== 'function') {
                return;
            }

            this.graphDock = new MainGraphsDock(this, {
                x: 444,
                y: 56,
                width: 420,
                height: Math.max(160, this.cameras.main.height - 68),
                onLayout: () => this.layoutWindows()
            });

            this.mainGraphWindows.thermal = this.graphDock.addWindow({
                key: 'thermal',
                title: 'Thermal',
                series: [
                    { key: 'targetTemp', color: 0xff5f57 },
                    { key: 'wellsAvg', color: 0x28c840 },
                    { key: 'lid', color: 0xffbd2e }
                ]
            });

            this.mainGraphWindows.resistance = this.graphDock.addWindow({
                key: 'resistance',
                title: 'Resistance',
                minimized: true,
                series: [
                    { key: 'resWellsAvg', color: 0x00d4ff },
                    { key: 'resLid', color: 0xff9f1a },
                    { key: 'resChamber', color: 0x9b7dff }
                ]
            });

            this.updateMainGraphWindowsData();
        }

        buildDataSummaryWindow(win) {
            const labelStyle = {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '11px',
                color: '#f5f5f5'
            };

            this.summaryInfoText = win.addContent(this.add.text(0, 0, 'Rows: 0\nSpan: --\nStart: --\nEnd: --\nSource: --', labelStyle), 0, 0);
            this.summaryLegendText = win.addContent(this.add.text(0, 0, 'wells avg  lid', {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '10px',
                color: '#d7dce2'
            }), 0, 88);

            this.summaryChart = this.add.graphics();
            win.addContent(this.summaryChart, 0, 108);

            this.addRoundedWindowButton(win, 0, 220, 152, 24, 'Recover Last Run', 0xff9f1a, '#2d1b00', () => {
                this.requestLastRunData();
            });
            this.addWindowButton(win, 162, 220, 152, 24, 'Raw Data', () => {
                this.showRawDataOverlay();
            });

            this.renderSummaryPanel();
        }

        initRawDataOverlay() {
            if (typeof document === 'undefined' || this.rawDataOverlayEl) {
                return;
            }

            const overlay = document.createElement('div');
            overlay.style.position = 'fixed';
            overlay.style.inset = '0';
            overlay.style.background = 'rgba(0,0,0,0.58)';
            overlay.style.display = 'none';
            overlay.style.alignItems = 'center';
            overlay.style.justifyContent = 'center';
            overlay.style.zIndex = '12000';

            const panel = document.createElement('div');
            panel.style.width = '80vw';
            panel.style.height = '80vh';
            panel.style.maxWidth = '80vw';
            panel.style.maxHeight = '80vh';
            panel.style.background = '#111317';
            panel.style.border = '1px solid rgba(255,255,255,0.18)';
            panel.style.borderRadius = '12px';
            panel.style.boxSizing = 'border-box';
            panel.style.padding = '10px 12px 12px 12px';
            panel.style.display = 'flex';
            panel.style.flexDirection = 'column';
            panel.style.gap = '8px';

            const header = document.createElement('div');
            header.style.display = 'flex';
            header.style.alignItems = 'center';
            header.style.justifyContent = 'space-between';

            const actions = document.createElement('div');
            actions.style.display = 'flex';
            actions.style.alignItems = 'center';
            actions.style.gap = '8px';

            const title = document.createElement('div');
            title.style.fontFamily = '"Montserrat Alternates", sans-serif';
            title.style.fontSize = '12px';
            title.style.fontWeight = '700';
            title.style.color = '#e6edf5';
            title.textContent = 'Raw Data';

            const closeBtn = document.createElement('button');
            closeBtn.type = 'button';
            closeBtn.textContent = ' '; 
            closeBtn.style.width = '14px';
            closeBtn.style.height = '14px';
            closeBtn.style.borderRadius = '999px';
            closeBtn.style.border = '1px solid rgba(255,255,255,0.22)';
            closeBtn.style.background = '#ff5f57';
            closeBtn.style.cursor = 'pointer';
            closeBtn.style.margin = '0';
            closeBtn.style.padding = '0';

            const downloadBtn = document.createElement('button');
            downloadBtn.type = 'button';
            downloadBtn.textContent = 'Download CSV';
            downloadBtn.style.height = '22px';
            downloadBtn.style.padding = '0 10px';
            downloadBtn.style.borderRadius = '7px';
            downloadBtn.style.border = '1px solid rgba(255,255,255,0.2)';
            downloadBtn.style.background = '#303236';
            downloadBtn.style.color = '#e6e6e6';
            downloadBtn.style.fontFamily = '"Montserrat Alternates", sans-serif';
            downloadBtn.style.fontSize = '10px';
            downloadBtn.style.cursor = 'pointer';

            const tableWrap = document.createElement('div');
            tableWrap.style.flex = '1';
            tableWrap.style.background = '#0a0c0f';
            tableWrap.style.border = '1px solid rgba(255,255,255,0.12)';
            tableWrap.style.borderRadius = '8px';
            tableWrap.style.overflow = 'auto';

            const table = document.createElement('table');
            table.style.borderCollapse = 'collapse';
            table.style.minWidth = 'max-content';
            table.style.width = '100%';
            table.style.fontFamily = '"Montserrat Alternates", sans-serif';
            table.style.fontSize = '10px';
            table.style.color = '#d7dce2';
            tableWrap.appendChild(table);

            actions.appendChild(downloadBtn);
            actions.appendChild(closeBtn);

            header.appendChild(title);
            header.appendChild(actions);
            panel.appendChild(header);
            panel.appendChild(tableWrap);
            overlay.appendChild(panel);

            overlay.addEventListener('click', (event) => {
                if (event.target === overlay) {
                    this.hideRawDataOverlay();
                }
            });
            closeBtn.addEventListener('click', () => this.hideRawDataOverlay());
            downloadBtn.addEventListener('click', () => this.downloadRawDataCsv());

            document.body.appendChild(overlay);

            this.rawDataOverlayEl = overlay;
            this.rawDataTitleEl = title;
            this.rawDataTableWrapEl = tableWrap;
            this.rawDataTableEl = table;
            this.rawDataCloseEl = closeBtn;
            this.rawDataDownloadEl = downloadBtn;
            this.layoutRawDataOverlay();
        }

        layoutRawDataOverlay() {
            if (!this.rawDataOverlayEl) {
                return;
            }
        }

        getFilteredRawDataRows(raw) {
            const lines = String(raw || '')
                .split(/\r?\n/)
                .map((line) => line.trim())
                .filter((line) => line.length > 0);

            if (lines.length === 0) {
                return [];
            }

            let startIndex = 0;
            let endIndex = lines.length;
            if (lines[0].toLowerCase() === 'start') {
                startIndex = 1;
            }
            if (endIndex > startIndex && lines[endIndex - 1].toLowerCase() === 'stop') {
                endIndex -= 1;
            }

            return lines.slice(startIndex, endIndex)
                .map((line) => line.split(',').map((cell) => cell.trim()))
                .filter((cells) => cells.length > 0 && cells.some((cell) => cell.length > 0));
        }

        escapeHtml(text) {
            return String(text)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;');
        }

        getRawDataColumnNames(maxCols) {
            const names = [];
            names.push('time_cycle_ms');
            names.push('heater_goal_c');

            const colors = ['blue', 'red', 'green'];
            for (let well = 1; well <= 8; well++) {
                for (let color = 0; color < colors.length; color++) {
                    for (let pd = 1; pd <= 2; pd++) {
                        names.push(`fluo_w${well}_${colors[color]}_pd${pd}`);
                    }
                }
            }

            names.push('temp_well1_c');
            names.push('temp_well2_c');
            names.push('temp_well3_c');
            names.push('temp_lid_c');
            names.push('res_well1');
            names.push('res_well2');
            names.push('res_well3');
            names.push('res_lid');
            names.push('res_chamber');
            names.push('free_spiffs_pct');

            // Backward compatibility: old payloads with only 20 columns.
            const legacyNames = [
                'time_cycle_ms', 'heater_goal_c',
                'fluo_1', 'fluo_2', 'fluo_3', 'fluo_4', 'fluo_5', 'fluo_6', 'fluo_7', 'fluo_8',
                'temp_well1_c', 'temp_well2_c', 'temp_well3_c', 'temp_lid_c',
                'res_well1', 'res_well2', 'res_well3', 'res_lid', 'res_chamber', 'free_spiffs_pct'
            ];

            if (maxCols <= legacyNames.length) {
                return legacyNames.slice(0, maxCols);
            }

            if (names.length < maxCols) {
                const baseLen = names.length;
                for (let i = baseLen; i < maxCols; i++) {
                    names.push(`col_${i + 1}`);
                }
            }
            return names.slice(0, maxCols);
        }

        buildRawDataTableHtml(raw) {
            const rows = this.getFilteredRawDataRows(raw);

            if (rows.length === 0) {
                return '<tbody><tr><td style="padding:8px 10px;border-bottom:1px solid rgba(255,255,255,0.08);">No data rows available.</td></tr></tbody>';
            }

            const maxCols = rows.reduce((max, row) => Math.max(max, row.length), 0);
            const columnNames = this.getRawDataColumnNames(maxCols);
            const headerCells = ['<th style="position:sticky;top:0;background:#161b22;padding:6px 8px;border-right:1px solid rgba(255,255,255,0.1);text-align:left;">#</th>'];
            for (let i = 0; i < maxCols; i++) {
                const name = this.escapeHtml(columnNames[i] || `col_${i + 1}`);
                headerCells.push(`<th style="position:sticky;top:0;background:#161b22;padding:6px 8px;border-right:1px solid rgba(255,255,255,0.1);text-align:left;white-space:nowrap;">${name}</th>`);
            }

            const bodyRows = rows.map((row, rowIndex) => {
                const cells = [`<td style="padding:5px 8px;border-right:1px solid rgba(255,255,255,0.08);border-bottom:1px solid rgba(255,255,255,0.08);white-space:nowrap;color:#93a1b2;">${rowIndex + 1}</td>`];
                for (let i = 0; i < maxCols; i++) {
                    const cell = i < row.length ? this.escapeHtml(row[i]) : '';
                    cells.push(`<td style="padding:5px 8px;border-right:1px solid rgba(255,255,255,0.08);border-bottom:1px solid rgba(255,255,255,0.08);white-space:nowrap;">${cell}</td>`);
                }
                return `<tr>${cells.join('')}</tr>`;
            });

            return `<thead><tr>${headerCells.join('')}</tr></thead><tbody>${bodyRows.join('')}</tbody>`;
        }

        buildRawDataText(raw) {
            const rows = this.getFilteredRawDataRows(raw);

            if (rows.length === 0) {
                return 'No data received yet.';
            }

            return `Rows: ${rows.length}`;
        }

        toCsvCell(value) {
            const s = String(value == null ? '' : value);
            if (s.includes('"') || s.includes(',') || s.includes('\n')) {
                return `"${s.replace(/"/g, '""')}"`;
            }
            return s;
        }

        buildRawDataCsv(raw) {
            const rows = this.getFilteredRawDataRows(raw);
            if (rows.length === 0) {
                return 'no_data\n';
            }

            const maxCols = rows.reduce((max, row) => Math.max(max, row.length), 0);
            const columnNames = this.getRawDataColumnNames(maxCols);
            const csvRows = [];

            csvRows.push(['#', ...columnNames].map((c) => this.toCsvCell(c)).join(','));
            rows.forEach((row, rowIndex) => {
                const data = [];
                for (let i = 0; i < maxCols; i++) {
                    data.push(i < row.length ? row[i] : '');
                }
                csvRows.push([String(rowIndex + 1), ...data].map((c) => this.toCsvCell(c)).join(','));
            });

            return `${csvRows.join('\n')}\n`;
        }

        downloadRawDataCsv() {
            if (typeof document === 'undefined' || typeof window === 'undefined') {
                return;
            }

            const csv = this.buildRawDataCsv(this.summaryRawPayload);
            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
            const url = URL.createObjectURL(blob);

            const source = this.summaryState && this.summaryState.source ? this.summaryState.source : 'data';
            const stamp = new Date().toISOString().replace(/[:.]/g, '-');
            const filename = `qbyte-raw-${source}-${stamp}.csv`;

            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }

        refreshRawDataOverlay() {
            if (!this.rawDataTableEl || !this.rawDataTitleEl) {
                return;
            }

            const source = this.summaryState && this.summaryState.source ? this.summaryState.source : 'none';
            this.rawDataTitleEl.textContent = `Raw Data (${source}) - ${this.buildRawDataText(this.summaryRawPayload)}`;
            this.rawDataTableEl.innerHTML = this.buildRawDataTableHtml(this.summaryRawPayload);
        }

        showRawDataOverlay() {
            if (!this.rawDataOverlayEl) {
                return;
            }
            this.refreshRawDataOverlay();
            this.layoutRawDataOverlay();
            this.rawDataOverlayEl.style.display = 'flex';
        }

        hideRawDataOverlay() {
            if (this.rawDataOverlayEl) {
                this.rawDataOverlayEl.style.display = 'none';
            }
        }

        requestLastRunData() {
            this.enqueueWorkerFetch('/last_run_request', 'low');
        }

        parseProtocolCsv(raw) {
            const lines = String(raw || '')
                .split(/\r?\n/)
                .map((line) => line.trim())
                .filter((line) => line.length > 0);

            const dataLines = lines.filter((line) => line !== 'start' && line !== 'stop' && !line.startsWith('['));
            const points = [];
            let lastMemoryPct = null;

            dataLines.forEach((line) => {
                const fields = line.split(',').map((part) => part.trim());
                if (fields.length < 20) {
                    return;
                }

                const columnNames = this.getRawDataColumnNames(fields.length);
                const vars = {};
                for (let i = 0; i < fields.length; i++) {
                    const key = columnNames[i] || `col_${i + 1}`;
                    const num = Number(fields[i]);
                    if (Number.isFinite(num)) {
                        vars[key] = num;
                    }
                }

                const tMs = Number.isFinite(vars.time_cycle_ms) ? vars.time_cycle_ms : Number(fields[0]);
                const targetTemp = Number.isFinite(vars.heater_goal_c) ? vars.heater_goal_c : Number(fields[1]);

                // Temperatures are always the 10th..7th values from the end:
                // [..., temp_well1, temp_well2, temp_well3, temp_lid, res1, res2, res3, res_lid, res_chamber, free_spiffs]
                const tail = fields.length;
                const w1 = Number.isFinite(vars.temp_well1_c) ? vars.temp_well1_c : Number(fields[tail - 10]);
                const w2 = Number.isFinite(vars.temp_well2_c) ? vars.temp_well2_c : Number(fields[tail - 9]);
                const w3 = Number.isFinite(vars.temp_well3_c) ? vars.temp_well3_c : Number(fields[tail - 8]);
                const lid = Number.isFinite(vars.temp_lid_c) ? vars.temp_lid_c : Number(fields[tail - 7]);
                const r1 = Number.isFinite(vars.res_well1) ? vars.res_well1 : Number(fields[tail - 6]);
                const r2 = Number.isFinite(vars.res_well2) ? vars.res_well2 : Number(fields[tail - 5]);
                const r3 = Number.isFinite(vars.res_well3) ? vars.res_well3 : Number(fields[tail - 4]);
                const resLid = Number.isFinite(vars.res_lid) ? vars.res_lid : Number(fields[tail - 3]);
                const resChamber = Number.isFinite(vars.res_chamber) ? vars.res_chamber : Number(fields[tail - 2]);
                if (!Number.isFinite(tMs) || !Number.isFinite(targetTemp) || !Number.isFinite(w1) || !Number.isFinite(w2) || !Number.isFinite(w3) || !Number.isFinite(lid)) {
                    return;
                }

                const wellsAvg = (w1 + w2 + w3) / 3;
                const resWellsAvg = Number.isFinite(r1) && Number.isFinite(r2) && Number.isFinite(r3)
                    ? (r1 + r2 + r3) / 3
                    : null;
                points.push({
                    tMs,
                    targetTemp,
                    wellsAvg,
                    lid,
                    temp_well1_c: w1,
                    temp_well2_c: w2,
                    temp_well3_c: w3,
                    temp_lid_c: lid,
                    resWellsAvg,
                    resLid,
                    resChamber,
                    vars
                });

                const memoryRaw = String(fields[tail - 1]).replace('%', '').trim();
                const memoryValue = Number(memoryRaw);
                if (Number.isFinite(memoryValue)) {
                    lastMemoryPct = memoryValue;
                }
            });

            const startMs = points.length > 0 ? points[0].tMs : null;
            const endMs = points.length > 0 ? points[points.length - 1].tMs : null;
            const spanMs = Number.isFinite(startMs) && Number.isFinite(endMs)
                ? Math.max(0, endMs - startMs)
                : 0;

            return {
                count: points.length,
                spanMs: spanMs,
                startMs: startMs,
                endMs: endMs,
                lastMemoryPct: lastMemoryPct,
                points: points
            };
        }

        formatDuration(ms) {
            if (!Number.isFinite(ms) || ms <= 0) {
                return '0s';
            }

            const totalSeconds = Math.round(ms / 1000);
            const h = Math.floor(totalSeconds / 3600);
            const m = Math.floor((totalSeconds % 3600) / 60);
            const s = totalSeconds % 60;
            if (h > 0) {
                return `${h}h ${m}m ${s}s`;
            }
            if (m > 0) {
                return `${m}m ${s}s`;
            }
            return `${s}s`;
        }

        drawSummaryChart() {
            if (!this.summaryChart) {
                return;
            }

            const g = this.summaryChart;
            const x = 0;
            const y = 0;
            const width = 314;
            const height = 96;

            g.clear();
            g.fillStyle(0x0e1013, 1);
            g.fillRect(x, y, width, height);
            g.lineStyle(1, 0xffffff, 0.16);
            g.strokeRect(x, y, width, height);

            const points = this.summaryState.points;
            if (!Array.isArray(points) || points.length < 2) {
                g.lineStyle(1, 0x7d8894, 0.8);
                g.lineBetween(x + 8, y + height / 2, x + width - 8, y + height / 2);
                return;
            }

            const recent = points.slice(-220);
            const tMin = recent[0].tMs;
            const tMax = recent[recent.length - 1].tMs;
            const tRange = Math.max(1, tMax - tMin);

            let yMin = Infinity;
            let yMax = -Infinity;
            recent.forEach((p) => {
                if (!Number.isFinite(p.wellsAvg) || !Number.isFinite(p.lid) || !Number.isFinite(p.targetTemp)) {
                    return;
                }
                yMin = Math.min(yMin, p.wellsAvg, p.lid, p.targetTemp);
                yMax = Math.max(yMax, p.wellsAvg, p.lid, p.targetTemp);
            });

            if (!Number.isFinite(yMin) || !Number.isFinite(yMax)) {
                g.lineStyle(1, 0x7d8894, 0.8);
                g.lineBetween(x + 8, y + height / 2, x + width - 8, y + height / 2);
                return;
            }

            const yLow = 0;
            const yHigh = Math.max(5, yMax + 5);
            const yRange = Math.max(0.001, yHigh - yLow);

            const toX = (tMs) => x + 8 + ((tMs - tMin) / tRange) * (width - 16);
            const toY = (v) => y + height - 8 - ((v - yLow) / yRange) * (height - 16);

            g.lineStyle(1.4, 0x28c840, 0.95);
            g.beginPath();
            g.moveTo(toX(recent[0].tMs), toY(recent[0].wellsAvg));
            for (let i = 1; i < recent.length; i++) {
                g.lineTo(toX(recent[i].tMs), toY(recent[i].wellsAvg));
            }
            g.strokePath();

            g.lineStyle(1.4, 0xffbd2e, 0.95);
            g.beginPath();
            g.moveTo(toX(recent[0].tMs), toY(recent[0].lid));
            for (let i = 1; i < recent.length; i++) {
                g.lineTo(toX(recent[i].tMs), toY(recent[i].lid));
            }
            g.strokePath();

            g.lineStyle(1.4, 0xff5f57, 0.95);
            g.beginPath();
            g.moveTo(toX(recent[0].tMs), toY(recent[0].targetTemp));
            for (let i = 1; i < recent.length; i++) {
                g.lineTo(toX(recent[i].tMs), toY(recent[i].targetTemp));
            }
            g.strokePath();
        }

        renderSummaryPanel() {
            if (!this.summaryInfoText) {
                return;
            }

            const state = this.summaryState;
            const startText = Number.isFinite(state.startMs) ? `${Math.round(state.startMs / 1000)}s` : '--';
            const endText = Number.isFinite(state.endMs) ? `${Math.round(state.endMs / 1000)}s` : '--';
            const memoryText = Number.isFinite(state.lastMemoryPct) ? `${state.lastMemoryPct.toFixed(2)}%` : '--';
            const latest = state.points.length > 0 ? state.points[state.points.length - 1] : null;
            const latestTarget = latest ? latest.targetTemp.toFixed(2) : '--';
            const latestWellsAvg = latest ? latest.wellsAvg.toFixed(2) : '--';
            const latestLid = latest ? latest.lid.toFixed(2) : '--';

            this.summaryInfoText.setText(
                `Rows: ${state.count}\n` +
                `Span: ${this.formatDuration(state.spanMs)}\n` +
                `Start: ${startText}\n` +
                `End: ${endText}\n` +
                `Mem: ${memoryText}\n` +
                `Source: ${state.source}`
            );

            if (this.summaryLegendText) {
                this.summaryLegendText.setText(`target ${latestTarget}C    wells avg ${latestWellsAvg}C    lid ${latestLid}C`);
            }

            this.drawSummaryChart();
        }

        updateMainGraphWindowsData() {
            if (!this.graphDock) {
                return;
            }

            const points = this.summaryState && Array.isArray(this.summaryState.points)
                ? this.summaryState.points
                : [];

            this.graphDock.setData(points);
        }

        applySummaryFromRaw(raw, source) {
            if (typeof raw !== 'string' || raw.includes('[ERROR]')) {
                return;
            }

            this.summaryRawPayload = raw;

            const parsed = this.parseProtocolCsv(raw);
            this.summaryState = {
                ...parsed,
                source: source
            };

            if (this.data && typeof this.data.set === 'function') {
                this.data.set('summaryData', this.summaryState);
            }
            this.updateMainGraphWindowsData();
            this.refreshRawDataOverlay();
            this.renderSummaryPanel();
        }

        buildQueueTables(win) {
            const headerStyle = {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '10px',
                fontStyle: 'bold',
                color: '#8ab4f8'
            };

            const cellStyle = {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '9px',
                color: '#d6dbe1'
            };

            const rowHeight = 18;
            const rows = 5;

            const leftX = 0;
            const rightX = 192;
            const tableY = 64;
            const tableW = 186;
            const tableH = 126;

            const leftCols = [30, 22, 126];
            const rightCols = [62, 40, 84];

            win.addContent(this.add.text(0, 0, 'QUEUE', headerStyle), leftX + 6, tableY + 4);
            win.addContent(this.add.text(0, 0, 'RECURRENT', headerStyle), rightX + 6, tableY + 4);

            this.drawTableGrid(win, leftX, tableY + 20, tableW, rowHeight, rows, leftCols);
            this.drawTableGrid(win, rightX, tableY + 20, tableW, rowHeight, rows, rightCols);

            const leftHeader = ['ID', 'P', 'TASK'];
            const rightHeader = ['NAME', 'FREQ', 'TASK'];

            let colX = leftX + 4;
            leftHeader.forEach((h, i) => {
                win.addContent(this.add.text(0, 0, h, headerStyle), colX, tableY + 23);
                colX += leftCols[i];
            });

            colX = rightX + 4;
            rightHeader.forEach((h, i) => {
                win.addContent(this.add.text(0, 0, h, headerStyle), colX, tableY + 23);
                colX += rightCols[i];
            });

            this.queueLeftCells = [];
            this.queueRightCells = [];

            for (let r = 0; r < rows; r++) {
                const y = tableY + 23 + rowHeight * (r + 1);

                colX = leftX + 4;
                const leftRow = [];
                for (let c = 0; c < leftCols.length; c++) {
                    const t = win.addContent(this.add.text(0, 0, '', cellStyle), colX, y);
                    leftRow.push(t);
                    colX += leftCols[c];
                }
                this.queueLeftCells.push(leftRow);

                colX = rightX + 4;
                const rightRow = [];
                for (let c = 0; c < rightCols.length; c++) {
                    const t = win.addContent(this.add.text(0, 0, '', cellStyle), colX, y);
                    rightRow.push(t);
                    colX += rightCols[c];
                }
                this.queueRightCells.push(rightRow);
            }
        }

        drawTableGrid(win, x, y, width, rowHeight, rows, columns) {
            const g = this.add.graphics();
            g.fillStyle(0x0e1013, 1);
            g.fillRect(x, y, width, rowHeight * (rows + 1));
            g.lineStyle(1, 0xffffff, 0.12);
            g.strokeRect(x, y, width, rowHeight * (rows + 1));

            for (let r = 1; r <= rows; r++) {
                const yy = y + r * rowHeight;
                g.lineBetween(x, yy, x + width, yy);
            }

            let cx = x;
            columns.forEach((w) => {
                cx += w;
                if (cx < x + width) {
                    g.lineBetween(cx, y, cx, y + rowHeight * (rows + 1));
                }
            });

            win.addContent(g, 0, 0);
        }

        buildProtocolConfigWindow(win) {
            const leftPad = 10;
            const labelStyle = {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '11px',
                color: '#f5f5f5'
            };

            const sectionStyle = {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '11px',
                fontStyle: 'bold',
                color: '#8ab4f8'
            };

            win.addContent(this.add.text(0, 0, 'Base Config', sectionStyle), leftPad, 0);

            const baseRows = [
                {
                    key: 'cycleTimeSec',
                    label: 'Cycle time (s)',
                    min: 1,
                    max: 600,
                    endpoint: (v) => `/cycle_time?set=${Math.round(v * 1000)}`
                },
                {
                    key: 'lidTemp',
                    label: 'Lid temp (C)',
                    min: 30,
                    max: 130,
                    endpoint: (v) => `/lid_temp?set=${Math.round(v)}`
                },
                {
                    key: 'lidDiff',
                    label: 'Lid diff (C)',
                    min: 0,
                    max: 50,
                    endpoint: (v) => `/lid_diff?set=${Math.round(v)}`
                }
            ];

            let y = 24;
            baseRows.forEach((row) => {
                win.addContent(this.add.text(0, 0, row.label, labelStyle), leftPad + 18, y);
                this.addHelpIconToWindow(win, leftPad + 8, y + 6, this.getConfigHelpText(row.key));
                this.createEditableProtocolField(win, {
                    key: row.key,
                    x: leftPad + 150,
                    y: y - 4,
                    width: 88,
                    min: row.min,
                    max: row.max,
                    allowDecimal: false
                });
                const applyRow = () => {
                    const value = this.getProtocolFieldNumber(row.key, this.protocolConfig[row.key], row.min, row.max);
                    this.protocolConfig[row.key] = value;
                    this.protocolFields[row.key].textObj.setText(String(value));
                    this.enqueueWorkerFetch(row.endpoint(value), 'normal');
                    if (row.key === 'cycleTimeSec' && this.protocolRunning) {
                        this.updateProtocolDataRecurring(true);
                    }
                    this.updateFieldCaretPosition(this.protocolFields[row.key]);
                };
                this.protocolFields[row.key].apply = applyRow;
                this.addWindowButton(win, leftPad + 246, y - 4, 68, 20, 'Set', applyRow);
                y += 32;
            });

            y += 4;

            // Melting mode switch mirrors old UI behavior: hide melting config when disabled.
            const switchGroup = this.createToggleSwitch(this.protocolConfig.isMelting, (enabled) => {
                this.protocolConfig.isMelting = enabled;
                this.updateMeltingVisibility();
                this.renderProtocolActionButtons();
            });
            win.addContent(switchGroup, leftPad, y + 1);
            win.addContent(this.add.text(0, 0, 'Melting Mode', sectionStyle), leftPad + 34, y);
            this.addHelpIconToWindow(win, leftPad + 134, y + 1, this.getConfigHelpText('isMelting'));

            y += 28;
            this.meltingOptionsContainer = this.add.container(0, 0);
            win.addContent(this.meltingOptionsContainer, leftPad, y);

            this.meltingVisibilityObjects = [];

            let meltingY = 0;
            this.meltingOptionsContainer.add(this.add.text(0, meltingY, 'Melting Config', sectionStyle));
            meltingY += 24;

            const meltingRows = [
                {
                    key: 'meltingStep',
                    label: 'Temp step (C)',
                    min: 0.1,
                    max: 5,
                    endpoint: (v) => `/melting_step?set=${Number(v).toFixed(1)}`
                },
                {
                    key: 'meltingTimeSec',
                    label: 'Step time (s)',
                    min: 1,
                    max: 120,
                    endpoint: (v) => `/melting_time?set=${Math.round(v * 1000)}`
                }
            ];

            meltingRows.forEach((row) => {
                this.meltingOptionsContainer.add(this.add.text(18, meltingY, row.label, labelStyle));
                this.addHelpIconToContainer(this.meltingOptionsContainer, 8, meltingY + 6, this.getConfigHelpText(row.key));

                const fieldContainer = this.createEditableProtocolField(win, {
                    key: row.key,
                    x: leftPad + 150,
                    y: y + meltingY - 4,
                    width: 88,
                    min: row.min,
                    max: row.max,
                    allowDecimal: row.key === 'meltingStep'
                });
                this.meltingVisibilityObjects.push(fieldContainer);

                const applyRow = () => {
                    const value = this.getProtocolFieldNumber(row.key, this.protocolConfig[row.key], row.min, row.max);
                    this.protocolConfig[row.key] = value;
                    this.protocolFields[row.key].textObj.setText(String(value));
                    this.enqueueWorkerFetch(row.endpoint(value), 'normal');
                    this.updateFieldCaretPosition(this.protocolFields[row.key]);
                };
                this.protocolFields[row.key].apply = applyRow;
                const setBtn = this.addWindowButton(win, leftPad + 246, y + meltingY - 4, 68, 20, 'Set', applyRow);
                this.meltingVisibilityObjects.push(setBtn);

                meltingY += 32;
            });

            this.meltingOptionsContainer.add(this.add.text(18, meltingY + 2, 'Range (C)', labelStyle));
            this.addHelpIconToContainer(this.meltingOptionsContainer, 8, meltingY + 8, this.getConfigHelpText('range'));
            const sliderRefs = this.createRangeSlider(win, leftPad + 76, y + meltingY, 146, 0, 100);
            this.meltingVisibilityObjects.push(sliderRefs.slider);
            const rangeSetBtn = this.addWindowButton(win, leftPad + 264, y + meltingY - 1, 50, 20, 'Set', () => {
                const endpoint = `/melting_range?set=${this.protocolConfig.rangeStart},${this.protocolConfig.rangeEnd}`;
                this.enqueueWorkerFetch(endpoint, 'normal');
            });
            this.meltingVisibilityObjects.push(rangeSetBtn);

            meltingY += 38;
            const actionTopOffset = 10;
            this.protocolActionCollapsedY = y + actionTopOffset;
            this.protocolActionExpandedY = y + 126 + actionTopOffset;

            y += 126;
            this.protocolActionContainer = this.add.container(0, 0);
            win.addContent(this.protocolActionContainer, leftPad, this.protocolActionExpandedY);
            this.protocolWindowExpandedHeight = win.expandedHeight;
            this.protocolWindowCollapsedHeight = Math.max(232, this.protocolWindowExpandedHeight - 126);
            this.renderProtocolActionButtons();
            this.updateMeltingVisibility(false);
        }

        createToggleSwitch(initialState, onChange) {
            const track = this.add.graphics();
            const drawTrack = (enabled) => {
                track.clear();
                track.fillStyle(enabled ? 0x28c840 : 0xff5f57, 1);
                track.lineStyle(1, 0xffffff, 0.22);
                track.fillRoundedRect(0, 0, 28, 14, 7);
                track.strokeRoundedRect(0, 0, 28, 14, 7);
            };
            drawTrack(initialState);

            const knob = this.add.circle(initialState ? 20 : 8, 7, 4.5, 0xffffff, 1);
            const hit = this.add.zone(14, 7, 28, 14).setOrigin(0.5);
            const group = this.add.container(0, 0, [track, knob, hit]);

            hit.setInteractive({ useHandCursor: true });
            knob.setInteractive({ useHandCursor: true });

            const toggle = () => {
                const next = !this.protocolConfig.isMelting;
                drawTrack(next);
                knob.setX(next ? 20 : 8);
                onChange(next);
            };

            hit.on('pointerdown', toggle);
            knob.on('pointerdown', toggle);
            return group;
        }

        getConfigHelpText(key) {
            const map = {
                cycleTimeSec: 'Time between acquisition cycles, in seconds.',
                lidTemp: 'Target lid temperature in degrees C.',
                lidDiff: 'Difference between lid target and current lid temperature the device waits for before heating reactions (to avoid condensation).',
                isMelting: 'Enable melting curve mode and its related parameters.',
                meltingStep: 'Temperature increment between melting points, in degrees C.',
                meltingTimeSec: 'Hold time per melting step, in seconds.',
                range: 'Temperature range used for melting analysis.',
                runTempC: 'Is the temperature of the protocol in degrees.'
            };
            return map[key] || 'Configuration parameter.';
        }

        addRoundedWindowButton(win, x, y, width, height, label, bgColor, textColor, onClick) {
            const bg = this.add.graphics();
            const drawBg = (state) => {
                let fill = bgColor;
                if (state === 'hover') {
                    fill = this.mixColor(bgColor, 0xffffff, 0.2);
                } else if (state === 'pressed') {
                    fill = this.mixColor(bgColor, 0x000000, 0.2);
                }
                bg.clear();
                bg.fillStyle(fill, 1);
                bg.lineStyle(1, bgColor, 1);
                bg.fillRoundedRect(0, 0, width, height, 11);
                bg.strokeRoundedRect(0, 0, width, height, 11);
            };
            drawBg('normal');

            const hit = this.add.zone(width / 2, height / 2, width, height).setOrigin(0.5);
            hit.setInteractive({ useHandCursor: true });

            const text = this.add.text(width / 2, height / 2, label, {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '10px',
                fontStyle: 'bold',
                color: textColor
            }).setOrigin(0.5);

            const group = this.add.container(0, 0, [bg, hit, text]);
            hit.on('pointerover', () => drawBg('hover'));
            hit.on('pointerout', () => drawBg('normal'));
            hit.on('pointerdown', () => drawBg('pressed'));
            hit.on('pointerup', () => drawBg('hover'));
            this.attachButtonPressEffect(group, hit, onClick);
            win.addContent(group, x, y);
            return group;
        }

        mixColor(from, to, t) {
            const clamped = this.clampNumber(Number(t) || 0, 0, 1);
            const fr = (from >> 16) & 0xff;
            const fg = (from >> 8) & 0xff;
            const fb = from & 0xff;
            const tr = (to >> 16) & 0xff;
            const tg = (to >> 8) & 0xff;
            const tb = to & 0xff;
            const r = Math.round(fr + (tr - fr) * clamped);
            const g = Math.round(fg + (tg - fg) * clamped);
            const b = Math.round(fb + (tb - fb) * clamped);
            return (r << 16) | (g << 8) | b;
        }

        attachButtonPressEffect(container, hitTarget, onClick) {
            if (!container || !hitTarget || !hitTarget.on) {
                return;
            }

            const pressScale = 0.97;
            const hoverScale = 1.015;
            const reset = () => {
                container.setScale(1);
                container.setAlpha(1);
            };

            hitTarget.on('pointerover', () => {
                container.setScale(hoverScale);
                container.setAlpha(0.98);
            });

            hitTarget.on('pointerdown', () => {
                container.setScale(pressScale);
                container.setAlpha(0.92);
            });
            hitTarget.on('pointerup', () => {
                reset();
                if (typeof onClick === 'function') {
                    onClick();
                }
            });
            hitTarget.on('pointerout', reset);
        }

        addHelpIconToWindow(win, x, y, message) {
            const icon = this.createHelpIcon(message);
            win.addContent(icon, x, y);
            return icon;
        }

        addHelpIconToContainer(container, x, y, message) {
            const icon = this.createHelpIcon(message);
            icon.setPosition(x, y);
            container.add(icon);
            return icon;
        }

        createHelpIcon(message) {
            const circle = this.add.circle(0, 0, 7, 0x2a2f36, 1);
            circle.setStrokeStyle(1, 0xffffff, 0.28);
            const q = this.add.text(0, 0, '?', {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '10px',
                fontStyle: 'bold',
                color: '#d7e0ea'
            }).setOrigin(0.5);
            const hit = this.add.zone(0, 0, 14, 14).setOrigin(0.5);
            hit.setInteractive({ useHandCursor: true });

            const icon = this.add.container(0, 0, [circle, q, hit]);

            hit.on('pointerover', (pointer) => {
                this.showHelpTooltip(message, pointer.x, pointer.y);
            });
            hit.on('pointermove', (pointer) => {
                this.showHelpTooltip(message, pointer.x, pointer.y);
            });
            hit.on('pointerout', () => {
                this.hideHelpTooltip();
            });

            return icon;
        }

        showHelpTooltip(message, x, y) {
            if (!this.helpTooltip || !this.helpTooltipBg || !this.helpTooltipText) {
                return;
            }

            this.helpTooltipText.setText(message);
            const pad = 6;
            const w = this.helpTooltipText.width + pad * 2;
            const h = this.helpTooltipText.height + pad * 2;

            this.helpTooltipBg.clear();
            this.helpTooltipBg.fillStyle(0x111418, 0.96);
            this.helpTooltipBg.fillRoundedRect(0, 0, w, h, 6);
            this.helpTooltipBg.lineStyle(1, 0xffffff, 0.18);
            this.helpTooltipBg.strokeRoundedRect(0, 0, w, h, 6);
            this.helpTooltipText.setPosition(pad, pad);

            this.helpTooltip.setPosition(x + 12, y + 12);
            this.helpTooltip.setVisible(true);
        }

        hideHelpTooltip() {
            if (this.helpTooltip) {
                this.helpTooltip.setVisible(false);
            }
        }

        updateMeltingVisibility(animated = true) {
            if (!this.meltingOptionsContainer) {
                return;
            }

            const visible = this.protocolConfig.isMelting;

            const setMeltingObjectsVisible = (isVisible) => {
                this.meltingOptionsContainer.setVisible(isVisible);
                this.meltingVisibilityObjects.forEach((obj) => {
                    if (obj && obj.setVisible) {
                        obj.setVisible(isVisible);
                    }
                });
            };

            if (!animated || !this.protocolActionContainer) {
                setMeltingObjectsVisible(visible);
                this.protocolActionContainer.y = visible ? this.protocolActionExpandedY : this.protocolActionCollapsedY;
                if (this.protocolWindow) {
                    this.protocolWindow.expandedHeight = visible ? this.protocolWindowExpandedHeight : this.protocolWindowCollapsedHeight;
                    this.layoutWindows();
                }
            } else {
                if (this.meltingCollapseTween) {
                    this.meltingCollapseTween.stop();
                    this.meltingCollapseTween = null;
                }

                if (this.protocolWindowHeightTween) {
                    this.protocolWindowHeightTween.stop();
                    this.protocolWindowHeightTween = null;
                }

                if (visible) {
                    setMeltingObjectsVisible(true);
                    this.meltingOptionsContainer.alpha = 0;
                    this.meltingVisibilityObjects.forEach((obj) => {
                        if (obj && obj.alpha != null) {
                            obj.alpha = 0;
                        }
                    });
                }

                this.meltingCollapseTween = this.tweens.add({
                    targets: this.protocolActionContainer,
                    y: visible ? this.protocolActionExpandedY : this.protocolActionCollapsedY,
                    duration: 500,
                    ease: 'Sine.easeInOut'
                });

                if (this.protocolWindow) {
                    this.protocolWindowHeightTween = this.tweens.add({
                        targets: this.protocolWindow,
                        expandedHeight: visible ? this.protocolWindowExpandedHeight : this.protocolWindowCollapsedHeight,
                        duration: 500,
                        ease: 'Sine.easeInOut',
                        onUpdate: () => this.layoutWindows(),
                        onComplete: () => this.layoutWindows()
                    });
                }

                this.tweens.add({
                    targets: [this.meltingOptionsContainer, ...this.meltingVisibilityObjects],
                    alpha: visible ? 1 : 0,
                    duration: 500,
                    ease: 'Sine.easeInOut',
                    onComplete: () => {
                        if (!visible) {
                            setMeltingObjectsVisible(false);
                        }
                    }
                });
            }

            if (!visible && this.activeProtocolField && this.activeProtocolField.startsWith('melting')) {
                this.setActiveProtocolField(null);
            }
        }

        createEditableProtocolField(win, options) {
            const bg = this.add.rectangle(0, 0, options.width, 20, 0x0f1113, 1).setOrigin(0, 0);
            bg.setStrokeStyle(1, 0xffffff, 0.22);
            bg.setInteractive({ useHandCursor: true });

            const value = this.protocolConfig[options.key];
            const txt = this.add.text(6, 4, String(value), {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '11px',
                color: '#d7dce2'
            }).setOrigin(0, 0);

            const caret = this.add.text(6 + txt.width + 1, 4, '|', {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '11px',
                color: '#7ca8ff'
            }).setOrigin(0, 0).setVisible(false);

            const field = this.add.container(0, 0, [bg, txt, caret]);
            win.addContent(field, options.x, options.y);
            this.protocolFields[options.key] = {
                textObj: txt,
                bg: bg,
                caret: caret,
                allowDecimal: !!options.allowDecimal,
                apply: null
            };

            bg.on('pointerdown', () => {
                this.setActiveProtocolField(options.key);
            });

            return field;
        }

        setActiveProtocolField(key) {
            Object.keys(this.protocolFields).forEach((fieldKey) => {
                const field = this.protocolFields[fieldKey];
                if (field && field.bg) {
                    field.bg.setStrokeStyle(1, 0xffffff, 0.22);
                    if (field.caret) {
                        field.caret.setVisible(false);
                    }
                }
            });

            if (this.fieldCaretTween) {
                this.fieldCaretTween.stop();
                this.fieldCaretTween = null;
            }

            this.activeProtocolField = key;
            if (!key) {
                return;
            }

            const activeField = this.protocolFields[key];
            if (activeField && activeField.bg) {
                activeField.bg.setStrokeStyle(1, 0x7ca8ff, 0.9);
                this.updateFieldCaretPosition(activeField);
                if (activeField.caret) {
                    activeField.caret.setVisible(true);
                    this.fieldCaretTween = this.tweens.add({
                        targets: activeField.caret,
                        alpha: { from: 1, to: 0.15 },
                        duration: 420,
                        yoyo: true,
                        repeat: -1
                    });
                }
            }
        }

        updateFieldCaretPosition(field) {
            if (!field || !field.textObj || !field.caret) {
                return;
            }
            field.caret.setX(6 + field.textObj.width + 1);
        }

        createRangeSlider(win, x, y, width, min, max) {
            const trackY = 12;
            const track = this.add.rectangle(0, trackY, width, 4, 0x3a3f45, 1).setOrigin(0, 0.5);
            const selected = this.add.rectangle(0, trackY, width, 4, 0x7ca8ff, 1).setOrigin(0, 0.5);
            const leftHandle = this.add.circle(0, trackY, 6, 0xe6edf5, 1);
            const rightHandle = this.add.circle(width, trackY, 6, 0xe6edf5, 1);
            const valueText = this.add.text(width + 8, 4, `${this.protocolConfig.rangeStart}-${this.protocolConfig.rangeEnd}`, {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '10px',
                color: '#d7dce2'
            });

            const slider = this.add.container(0, 0, [track, selected, leftHandle, rightHandle, valueText]);
            win.addContent(slider, x, y);

            const valueToX = (v) => ((v - min) / (max - min)) * width;
            const xToValue = (px) => Math.round(min + (px / width) * (max - min));

            leftHandle.setX(valueToX(this.protocolConfig.rangeStart));
            rightHandle.setX(valueToX(this.protocolConfig.rangeEnd));

            const refresh = () => {
                const lx = Math.min(leftHandle.x, rightHandle.x);
                const rx = Math.max(leftHandle.x, rightHandle.x);
                selected.setX(lx);
                selected.setDisplaySize(Math.max(2, rx - lx), 4);
                this.protocolConfig.rangeStart = xToValue(lx);
                this.protocolConfig.rangeEnd = xToValue(rx);
                valueText.setText(`${this.protocolConfig.rangeStart}-${this.protocolConfig.rangeEnd}`);
            };

            [leftHandle, rightHandle].forEach((h) => {
                h.setInteractive({ draggable: true, useHandCursor: true });
                this.input.setDraggable(h);
                h.on('drag', (pointer) => {
                    const localX = pointer.x - win.container.x - slider.x;
                    h.x = this.clampNumber(localX, 0, width);
                    refresh();
                });
            });

            refresh();
            this.rangeSlider = { slider, leftHandle, rightHandle, refresh };
            return this.rangeSlider;
        }

        renderProtocolActionButtons() {
            if (!this.protocolActionContainer) {
                return;
            }

            this.protocolActionContainer.removeAll(true);

            if (!this.protocolRunning) {
                const tempInput = this.createActionInput(0, 5, 52, 22, 'runTempC', 0, 120, false);
                this.addHelpIconToContainer(this.protocolActionContainer, 70, 16, this.getConfigHelpText('runTempC'));
                const runBtn = this.createActionButton(82, 5, 232, 22, 'Run', 0x28c840, '#0d2510', () => {
                    const runTemp = this.getProtocolFieldNumber('runTempC', this.protocolConfig.runTempC, 0, 120);
                    this.protocolConfig.runTempC = runTemp;
                    if (this.protocolFields.runTempC && this.protocolFields.runTempC.textObj) {
                        this.protocolFields.runTempC.textObj.setText(String(runTemp));
                    }

                    const endpoint = this.protocolConfig.isMelting ? '/RunMelting' : `/Run?degrees=${runTemp}`;
                    this.enqueueWorkerFetch(endpoint, 'high');
                    // Delay first one-shot pull so the first cycle has time to produce rows.
                    this.time.delayedCall(5000, () => {
                        this.enqueueWorkerFetch('/data_request', 'normal');
                    });
                    this.time.delayedCall(6200, () => {
                        this.enqueueWorkerFetch('/data_request', 'normal');
                    });
                });
                this.protocolActionContainer.add([tempInput, runBtn]);
                return;
            }

            const stopBtn = this.createActionButton(0, 5, 152, 22, 'Stop', 0xff5f57, '#3b0e0b', () => {
                this.enqueueWorkerFetch('/Stop', 'high');
            });
            const manualBtn = this.createActionButton(162, 5, 152, 22, 'Manual Cycle', 0xffbd2e, '#3d2a00', () => {
                this.enqueueWorkerFetch('/manual_cycle', 'high');
            });

            this.protocolActionContainer.add([stopBtn, manualBtn]);
        }

        createActionButton(x, y, width, height, label, bgColor, textColor, onClick) {
            const bg = this.add.graphics();
            const drawBg = (state) => {
                let fill = bgColor;
                if (state === 'hover') {
                    fill = this.mixColor(bgColor, 0xffffff, 0.2);
                } else if (state === 'pressed') {
                    fill = this.mixColor(bgColor, 0x000000, 0.2);
                }
                bg.clear();
                bg.fillStyle(fill, 1);
                bg.lineStyle(1, bgColor, 1);
                bg.fillRoundedRect(0, 0, width, height, 10);
                bg.strokeRoundedRect(0, 0, width, height, 10);
            };
            drawBg('normal');

            const hit = this.add.zone(width / 2, height / 2, width, height).setOrigin(0.5);
            hit.setInteractive({ useHandCursor: true });

            const text = this.add.text(width / 2, height / 2, label, {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '10px',
                fontStyle: 'bold',
                color: textColor
            }).setOrigin(0.5);

            const group = this.add.container(x, y, [bg, hit, text]);
            hit.on('pointerover', () => drawBg('hover'));
            hit.on('pointerout', () => drawBg('normal'));
            hit.on('pointerdown', () => drawBg('pressed'));
            hit.on('pointerup', () => drawBg('hover'));
            this.attachButtonPressEffect(group, hit, onClick);
            return group;
        }

        createActionInput(x, y, width, height, key, min, max, allowDecimal) {
            const bg = this.add.rectangle(0, 0, width, height, 0x0f1113, 1).setOrigin(0, 0);
            bg.setStrokeStyle(1, 0xffffff, 0.22);
            bg.setInteractive({ useHandCursor: true });

            const current = Number.isFinite(this.protocolConfig[key]) ? this.protocolConfig[key] : 0;
            const txt = this.add.text(6, 5, String(current), {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '10px',
                color: '#d7dce2'
            }).setOrigin(0, 0);

            const caret = this.add.text(6 + txt.width + 1, 5, '|', {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '10px',
                color: '#7ca8ff'
            }).setOrigin(0, 0).setVisible(false);

            this.protocolFields[key] = {
                textObj: txt,
                bg: bg,
                caret: caret,
                allowDecimal: !!allowDecimal,
                apply: () => {
                    const value = this.getProtocolFieldNumber(key, this.protocolConfig[key], min, max);
                    this.protocolConfig[key] = value;
                    txt.setText(String(value));
                    this.updateFieldCaretPosition(this.protocolFields[key]);
                }
            };

            bg.on('pointerdown', () => {
                this.setActiveProtocolField(key);
            });

            return this.add.container(x, y, [bg, txt, caret]);
        }

        addWindowButton(win, x, y, width, height, label, onClick) {
            const rect = this.add.rectangle(0, 0, width, height, 0x303236, 1).setOrigin(0, 0);
            rect.setStrokeStyle(1, 0xffffff, 0.2);
            rect.setInteractive({ useHandCursor: true });

            const text = this.add.text(width / 2, height / 2, label, {
                fontFamily: '"Montserrat Alternates"',
                fontSize: '10px',
                color: '#e6e6e6'
            }).setOrigin(0.5);

            const group = this.add.container(0, 0, [rect, text]);
            this.attachButtonPressEffect(group, rect, onClick);
            win.addContent(group, x, y);
            return group;
        }

        enqueueWorkerFetch(endpoint, priority = 'normal') {
            if (!this.pingWorker) {
                return;
            }
            this.pingWorker.postMessage({
                type: 'enqueue',
                kind: 'fetch',
                endpoint: endpoint,
                parser: 'text',
                priority: priority
            });
        }

        clampNumber(value, min, max) {
            return Math.max(min, Math.min(max, value));
        }

        roundByStep(value, step) {
            if (step >= 1) {
                return Math.round(value);
            }
            return Number(value.toFixed(1));
        }

        getProtocolFieldNumber(key, fallback, min, max) {
            const raw = this.protocolFields[key] ? this.protocolFields[key].textObj.text : String(fallback);
            const parsed = Number(String(raw).trim());
            if (!Number.isFinite(parsed)) {
                return fallback;
            }

            const field = this.protocolFields[key];
            const bounded = this.clampNumber(parsed, min, max);
            if (field && field.allowDecimal) {
                return Number(bounded.toFixed(1));
            }
            return Math.round(bounded);
        }

        layoutWindows() {
            if (!this.windows || this.windows.length === 0) {
                return;
            }

            const left = 12;
            let y = 56;
            const spacing = 12;
            const cameraWidth = this.cameras.main.width;
            const cameraHeight = this.cameras.main.height;
            const maxWidth = Math.min(420, cameraWidth - 24);

            this.windows.forEach((win) => {
                win.width = maxWidth;
                win.headerHitArea.setSize(maxWidth, win.titleBarHeight);
                win.headerHitArea.setPosition(maxWidth / 2, win.titleBarHeight / 2);
                win.render();
                win.setPosition(left, y);
                y += win.getHeight() + spacing;
            });

            if (this.graphDock) {
                const rightX = left + maxWidth + 12;
                const rightWidth = cameraWidth - rightX - 12;
                if (rightWidth >= 260) {
                    this.graphDock.setVisible(true);
                    this.graphDock.setArea(rightX, 56, rightWidth, Math.max(140, cameraHeight - 68));
                } else {
                    this.graphDock.setVisible(false);
                }
            }
        }

        parseMemoryPercent(raw) {
            if (raw == null) {
                return null;
            }

            const cleaned = String(raw).replace('%', '').trim();
            const n = Number(cleaned);
            if (!Number.isFinite(n)) {
                return null;
            }

            return this.clampNumber(n, 0, 100);
        }

        drawMemoryBar(x, y, width, height) {
            if (!this.memoryBar) return;

            this.memoryBar.clear();
            this.memoryBar.fillStyle(0x1f2328, 1);
            this.memoryBar.fillRoundedRect(x, y, width, height, height / 2);
            this.memoryBar.lineStyle(1, 0xffffff, 0.18);
            this.memoryBar.strokeRoundedRect(x, y, width, height, height / 2);

            const percent = Number.isFinite(this.freeMemoryPercent) ? this.freeMemoryPercent : 0;
            const fillWidth = Math.max(2, Math.round((percent / 100) * (width - 2)));
            const fillColor = percent <= 10 ? 0xff5f57 : (percent <= 25 ? 0xffbd2e : 0x28c840);
            this.memoryBar.fillStyle(fillColor, 1);
            this.memoryBar.fillRoundedRect(x + 1, y + 1, fillWidth, Math.max(2, height - 2), (height - 2) / 2);
        }

        async refreshDeviceInfo() {
            try {
                const response = await fetch('/device-info', { cache: 'no-store' });
                if (!response.ok) {
                    return;
                }
                const payload = await response.json();
                if (payload && typeof payload === 'object') {
                    if (payload.ip) this.identity.ip = String(payload.ip);
                    if (payload.ssid) this.identity.ssid = String(payload.ssid);
                    if (payload.mdns) this.identity.mdns = String(payload.mdns);
                }

                this.ipText.setText(`IP: ${this.identity.ip}`);
                this.ssidText.setText(`SSID: ${this.identity.ssid}`);
                this.mdnsText.setText(`mDNS: ${this.identity.mdns}`);
                this.layoutTopBar();
            } catch (err) {
                // Keep last good values on transient fetch errors.
            }

            try {
                const response = await fetch('/free_memory', { cache: 'no-store' });
                if (!response.ok) {
                    return;
                }
                const raw = await response.text();
                const next = this.parseMemoryPercent(raw);
                if (Number.isFinite(next)) {
                    this.freeMemoryPercent = next;
                    this.layoutTopBar();
                }
            } catch (err) {
                // Keep last good memory reading on transient fetch errors.
            }
        }

        startDeviceInfoRefresh() {
            this.refreshDeviceInfo();
            this.deviceInfoTimer = this.time.addEvent({
                delay: 1000,
                callback: () => this.refreshDeviceInfo(),
                loop: true
            });
        }

        layoutTopBar() {
            const y = 12;
            const graphW = 64;
            const graphH = 16;

            const startX = 42;
            const ipColumnWidth = 122;
            const pingColumnWidth = 95;
            const graphGap = 5;
            const afterGraphGap = 14;
            const ssidColumnWidth = 100;
            const mdnsColumnWidth = 150;
            const memoryGap = 8;
            const memoryBarWidth = 56;
            const memoryBarHeight = 10;

            const ipX = startX;
            const pingX = ipX + ipColumnWidth;
            const graphX = pingX + pingColumnWidth + graphGap;
            const ssidX = graphX + graphW + afterGraphGap;
            const mdnsX = ssidX + ssidColumnWidth;
            const memoryLabelX = mdnsX + mdnsColumnWidth;
            const memoryBarX = memoryLabelX + 50 + memoryGap;

            this.ipText.setPosition(ipX, y);
            this.pingText.setPosition(pingX, y);
            this.drawPingSparkline(graphX, y + 1, graphW, graphH);
            this.ssidText.setPosition(ssidX, y);
            this.mdnsText.setPosition(mdnsX, y);
            if (this.memoryLabelText) {
                this.memoryLabelText.setText('memory');
                this.memoryLabelText.setPosition(memoryLabelX, y);
            }
            this.drawMemoryBar(memoryBarX, y + 4, memoryBarWidth, memoryBarHeight);
        }

        drawPingSparkline(x, y, width, height) {
            if (!this.pingGraph) return;

            this.pingGraph.clear();
            this.pingGraph.lineStyle(1, 0x666666, 1);
            this.pingGraph.strokeRect(x, y, width, height);

            const slots = this.pingHistory;
            const values = slots.filter((v) => Number.isFinite(v));
            if (values.length === 0) {
                this.pingGraph.lineStyle(1, 0x888888, 1);
                this.pingGraph.lineBetween(x + 2, y + height / 2, x + width - 2, y + height / 2);
                return;
            }

            const max = Math.max(...values);
            const min = Math.min(...values);
            const range = Math.max(1, max - min);
            const step = (width - 6) / 9;

            const pingColor = (value) => {
                if (value < 130) return 0x28c840;
                if (value <= 300) return 0xffbd2e;
                return 0xff5f57;
            };

            // Color the sparkline based on the latest available ping sample.
            let latestPing = null;
            for (let i = slots.length - 1; i >= 0; i--) {
                if (Number.isFinite(slots[i])) {
                    latestPing = slots[i];
                    break;
                }
            }
            const lineColor = Number.isFinite(latestPing) ? pingColor(latestPing) : 0x9aa3ad;
            this.pingGraph.lineStyle(1.2, lineColor, 0.95);
            let started = false;
            const plottedPoints = [];
            for (let i = 0; i < 10; i++) {
                const value = slots[i];
                const px = x + 3 + i * step;
                if (!Number.isFinite(value)) {
                    continue;
                }
                const normalized = (value - min) / range;
                const py = y + height - 3 - normalized * (height - 6);
                plottedPoints.push({ x: px, y: py, value: value });
                if (!started) {
                    this.pingGraph.beginPath();
                    this.pingGraph.moveTo(px, py);
                    started = true;
                } else {
                    this.pingGraph.lineTo(px, py);
                }
            }
            if (started) {
                this.pingGraph.strokePath();
            }

            // Keep the sparkline clean without point markers.
        }

        setupPingWorker() {
            if (!window.Worker) {
                return;
            }

            this.pingWorker = new Worker('worker.js');
            this.pingWorker.onmessage = (event) => {
                const msg = event.data || {};
                if (msg.type === 'queue') {
                    this.updateQueueWindow(msg);
                    return;
                }

                if (msg.type === 'data') {
                    this.handleWorkerData(msg);
                    return;
                }

                if (msg.type !== 'ping') {
                    return;
                }

                const connected = !!msg.connected;
                const ping = msg.pingMs == null ? '--' : String(msg.pingMs);
                const pingNumber = msg.pingMs == null ? null : Number(msg.pingMs);

                if (Number.isFinite(pingNumber)) {
                    this.pingHistory.shift();
                    this.pingHistory.push(pingNumber);
                }

                if (this.connectionDot) {
                    this.connectionDot.setFillStyle(connected ? 0x28c840 : 0xff5f57, 1);
                }

                this.pingText.setText(`PING: ${ping} ms`);
                this.layoutTopBar();
            };

            // Poll ping every second via a dedicated endpoint.
            this.pingWorker.postMessage({
                type: 'start',
                name: 'ping',
                endpoint: '/ping',
                intervalMs: 1000,
                priority: 'high'
            });

            this.pingWorker.postMessage({
                type: 'startDataPoll',
                name: 'device-info',
                endpoint: '/device-info',
                parser: 'json',
                intervalMs: 3000,
                priority: 'low'
            });

            this.pingWorker.postMessage({
                type: 'addRecurring',
                name: 'protocol-state',
                kind: 'fetch',
                endpoint: '/OnGoing',
                parser: 'text',
                intervalMs: 1000,
                priority: 'normal'
            });

            this.updateProtocolDataRecurring(this.protocolRunning);
            this.requestLastRunData();
        }

        updateQueueWindow(snapshot) {
            if (!this.queueWindowText || this.queueLeftCells.length === 0 || this.queueRightCells.length === 0) {
                return;
            }

            const active = snapshot.active
                ? `${snapshot.active.kind} ${snapshot.active.endpoint} (p${snapshot.active.priority})`
                : 'idle';
            const pendingCount = Array.isArray(snapshot.pending) ? snapshot.pending.length : 0;
            const completed = Number(snapshot.completedCount) || 0;

            this.queueWindowText.setText(`Active: ${active}\nPending: ${pendingCount}\nCompleted: ${completed}`);

            for (let i = 0; i < this.queueLeftCells.length; i++) {
                const row = this.queueLeftCells[i];
                const task = pendingCount ? snapshot.pending[i] : null;
                if (!task) {
                    row[0].setText(i === 0 && pendingCount === 0 ? '-' : '');
                    row[1].setText(i === 0 && pendingCount === 0 ? '-' : '');
                    row[2].setText(i === 0 && pendingCount === 0 ? '(empty)' : '');
                    continue;
                }

                row[0].setText(String(task.id));
                row[1].setText(String(task.priority));
                row[2].setText(`${task.kind} ${task.endpoint}`.slice(0, 18));
            }

            const recurring = Array.isArray(snapshot.recurring) ? snapshot.recurring : [];
            for (let i = 0; i < this.queueRightCells.length; i++) {
                const row = this.queueRightCells[i];
                const task = recurring[i];
                if (!task) {
                    row[0].setText(i === 0 && recurring.length === 0 ? '-' : '');
                    row[1].setText(i === 0 && recurring.length === 0 ? '-' : '');
                    row[2].setText(i === 0 && recurring.length === 0 ? '(none)' : '');
                    continue;
                }

                row[0].setText(String(task.name).slice(0, 7));
                row[1].setText(`${Math.round(task.intervalMs / 1000)}s`);
                row[2].setText(`${task.kind} ${task.endpoint}`.slice(0, 12));
            }
        }

        handleWorkerData(msg) {
            if (msg.endpoint === '/OnGoing') {
                const current = String(msg.value || '').trim() === '1';
                if (current !== this.protocolRunning) {
                    this.protocolRunning = current;
                    this.updateProtocolDataRecurring(current);
                    this.renderProtocolActionButtons();
                }
                return;
            }

            if (msg.endpoint === '/data_request') {
                this.applySummaryFromRaw(String(msg.value || ''), 'live');
                return;
            }

            if (msg.endpoint === '/last_run_request') {
                this.applySummaryFromRaw(String(msg.value || ''), 'last-run');
                return;
            }

            if (msg.endpoint === '/manual_cycle') {
                if (this.data && typeof this.data.set === 'function') {
                    this.data.set('manualCycleQueryAt', Date.now());
                }

                const answer = String(msg.value || '');
                if (answer.includes('[OK]')) {
                    this.time.delayedCall(1400, () => {
                        this.enqueueWorkerFetch('/data_request', 'normal');
                    });
                }
                return;
            }

            if (msg.endpoint !== '/device-info') {
                return;
            }

            const payload = msg.value;
            if (!payload || typeof payload !== 'object') {
                return;
            }

            if (payload.ip) this.identity.ip = String(payload.ip);
            if (payload.ssid) this.identity.ssid = String(payload.ssid);
            if (payload.mdns) this.identity.mdns = String(payload.mdns);

            this.ipText.setText(`IP: ${this.identity.ip}`);
            this.ssidText.setText(`SSID: ${this.identity.ssid}`);
            this.mdnsText.setText(`mDNS: ${this.identity.mdns}`);
            this.layoutTopBar();
        }

        updateProtocolDataRecurring(isRunning) {
            if (!this.pingWorker) {
                return;
            }

            if (!isRunning) {
                this.pingWorker.postMessage({ type: 'removeRecurring', name: 'protocol-data' });
                return;
            }

            this.pingWorker.postMessage({
                type: 'addRecurring',
                name: 'protocol-data',
                kind: 'fetch',
                endpoint: '/data_request',
                parser: 'text',
                intervalMs: Math.max(1000, this.protocolConfig.cycleTimeSec * 1000),
                priority: 'normal'
            });
        }

        shutdown() {
            if (this.deviceInfoTimer) {
                this.deviceInfoTimer.remove(false);
                this.deviceInfoTimer = null;
            }

            if (this.rawDataOverlayEl && this.rawDataOverlayEl.parentNode) {
                this.rawDataOverlayEl.parentNode.removeChild(this.rawDataOverlayEl);
            }
            this.rawDataOverlayEl = null;
            this.rawDataTitleEl = null;
            this.rawDataTableWrapEl = null;
            this.rawDataTableEl = null;
            this.rawDataCloseEl = null;
            this.rawDataDownloadEl = null;

            if (this.pingWorker) {
                this.pingWorker.postMessage({ type: 'stop' });
                this.pingWorker.terminate();
                this.pingWorker = null;
            }

            if (this.graphDock) {
                this.graphDock.destroy();
                this.graphDock = null;
            }
        }

        destroy() {
            this.shutdown();
        }
    }

